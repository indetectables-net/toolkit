===================
 Ascii Generator 2 
===================

Version 2.0.0 - Released 2011-09-26

Ascii Generator 2 / Ascii Generator dotNET / Ascgen 2, Copyright (C) 2005-11 Jonathan Mathews. All rights reserved.

This program comes with ABSOLUTELY NO WARRANTY; for details see 'gpl.txt'.
This is free software, and you are welcome to redistribute it under certain conditions; see 'gpl.txt' for details.

=====================

Website:
    http://ascgendotnet.jmsoftware.co.uk/
    http://sourceforge.net/projects/ascgen2/

For common issues, please check our frequently asked questions section:
    http://ascgendotnet.jmsoftware.co.uk/help/faq

For any other questions or problems you can contact me via:
    http://ascgendotnet.jmsoftware.co.uk/help/contact
    http://twitter.com/ascgen
    http://sourceforge.net/users/wardog_uk

Please submit bug reports or feature requests to our tracker
    http://sourceforge.net/tracker/?group_id=133786

=====================   

This program uses the amazing "Silk" icons by Mark James, which is under a Creative Commons Attribution 2.5 License.
    http://www.famfamfam.com/lab/icons/silk/