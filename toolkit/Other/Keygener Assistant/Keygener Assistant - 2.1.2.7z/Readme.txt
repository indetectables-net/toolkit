
*************************************************************************
*				                                        *
*           ..::.        Keygener Assistant        .::..                *
*				                                        *
*************************************************************************

Descreption :
-------------
Keygener Assistant is a Full tool that combines several functions
to facilitate the task and save time during the analysis of an algorithm

-------------------------------------------------------------------------

Operations :
------------

	+ BigNumbers Calculator
	+ Conversion & Encoding
	+ Hashing & CheckSum Calculator
	+ Cryptography Operations
	+ Hash & Crypto detector
        + System Information & System utils

For Change Log see history.txt :
-------------------------------------
About Us :
-------------------------------------

Coded By   : Mr Paradox

TEAM       : AT4RE

Home Page  : www.at4re.com 

E-Mail     : mr.paradox@hotmail.fr

-------------------------------------------------------------------------