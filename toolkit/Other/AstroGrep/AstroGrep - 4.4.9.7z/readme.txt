﻿Changelog for AstroGrep v4.4.9
===================================================================
Bugs
-126: Directory exclusions not being applied to sub directories

Featured Requests:
-146: Add Dark Theme

Patches:
N/A

Support Requests:
-014: Error HRESULT E_FAIL on any simple search (Issue with iFilter Plugin)

Other:
- Updated external dlls to latest versions
- Add enabled counts and tooltips for search option plugins and exclusions
- Check for divide by zero condition when reading encoding sample buffer
- Add safety check for file list height so it can't hide the results view (From forum)