DBG2AP Plugin v0.1 Coded by Agmcz & Sn!per X ^ AT4RE

Plugin exports patches data for a various debuggers to be used with AT4RE Patcher.

Release date:
  11-03-2017

Supported Debuggers:
  OllyDBG 1.10 (not modified).
  OllyDBG 2.01 (not modified).

Exported data can be used with:
  AT4RE Patcher v0.7.3 Beta and above.

Install:
- if you are using OllyDbg v1.10:
  Copy the dll placed in "OllyDbg v1.10" folder to OllyDbg>Plugins Folder.
- if you are using OllyDbg v2.01:
  Copy the dll placed in "OllyDbg v2.01" folder to OllyDbg>Plugins Folder.