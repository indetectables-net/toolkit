DBG2AP Plugin for x64dbg
This plugin helps you export patches data to be used with AT4RE Patcher.

Install
Copy the plugins to x64dbg folders
:  
    DBG2AP.dp32 to release/x86/plugins
  
    DBG2AP.dp64 to release/x64/plugins