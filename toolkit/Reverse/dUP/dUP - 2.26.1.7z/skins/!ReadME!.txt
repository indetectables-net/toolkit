Creating own skins

dUP support *.res files which can be created for example with:
 -Resource Hacker          [http://www.users.on.net/johnson/resourcehacker]
 -XN Resource Editor       [http://www.wilsonc.demon.co.uk]
 -Restorator 2005          [http://www.bome.com/restorator]
 -Resource Builder 2.0     [http://www.sicomponents.com]

 
Don't delete controls which have an ID number and also don not 
modify this number,else the patcher will not work. its no problem 
to add other controls like BMP Pictures.
