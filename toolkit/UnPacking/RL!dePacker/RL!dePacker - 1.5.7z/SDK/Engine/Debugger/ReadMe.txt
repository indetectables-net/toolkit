 This debugger.dll file is patched so it does not hide itself from detection. This way it will be detected
via IsDebuggerPresent API.