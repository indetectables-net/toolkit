ArmaDetachMe DB/CMII 0.1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 For XP and Armadillo 4.x:

 ArmaDetachMe CopyMemII 0.1 for Armadillo 4.x (CopyMemII + DebugBlocker + ...)
 ArmaDetachMe DebugBlocker 0.1 for Armadillo 4.x (DebugBlocker [no CopyMemII])

 Contact:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 coded by: ap0x
 web-site: http://ap0x.jezgra.net
 email:    ap0x.rce[at]gmail[dot][com]