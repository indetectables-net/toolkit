// ---------------------------------------------------------------------------
// Product identifier string defines.
#define SZPLUGINNAME    "Plugin for PExplorer\0"
#define SZDESCRIPTION   "Plugin for loading forms from PExplorer\0"
#define SZVERSION       "Version 1.0\0"
#define SZAUTHORINFO    "crypto\0"
// ---------------------------------------------------------------------------



