BDASM v2.5 Full version
-----------------------

- New Features v2.5 06-06-2005

	- 32bits Windows debugger
		- Command line
 		- Supports any application running in Ring 3 mode (user mode)
 		- Hardware/Software breakpoints with conditional expressions
 		- Memory dumping/editing capabilities (full executable dump or memory dump)
 		- Memory map
 		- Expression evaluator (built in registers, flags, etc.)
 		- Load symbol files (using ImageHlp library)
 		- Symbol Server technology support (automatically downloads Microsoft� 
 		symbols from internet or from any server on your network), for information on symbol server technology checkout Microsoft� symsrv page.
 		- Split symbols from file.
 		- JIT Debugging, BDASM could be configured as your default debugger 
 		so when and application crashes BDASM will take control of it allowing you to debug it.
 		- Could attach itself to a running process or debug it from the beginning
 		- Process viewer, mainly used to attach BDASM to a running process.

		
	- Fixed some memory leaks on the i386 plugin disassembler
	- License file system is removed
	
----------------------------------------------------------------------------------------
	
- What are the contents of the installed files?

	apilib.dat		-> API Library file (not needed to run the program)
	bdasm.exe		-> Main executable program
	bdasm.ini		-> Configuration file for BDASM environment
	bdasmdll.dll		-> BDASM Main DLL 
	bdasm.chm		-> BDASM manual in Windows Help format.
	Win32Debug.dll		-> Debugger DLL
	camouflage.ini		-> Alternative configuration file for BDASM environment
	deep_blue_sea.ini	-> Alternative configuration file for BDASM environment
	LikeSice.ini		-> Alternative configuration file for BDASM environment
	old_school.ini		-> Alternative configuration file for BDASM environment
	readme.txt		-> You'r reading it now :)
	
Plug-in files are stored inside the plugins directory.

The alternative configuration files are different color schemes for BDASM 
environment, you can overwrite the default scheme (bdasm.ini) by any of the 
alternative files.

Remember to check http://www.bdasm.com for updates and info.

(c) 2003,2004 Manuel Jim�nez

Legal Disclaimer

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING 
(BUT NOT LIMITED TO) THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS 
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL 
DAMAGES INCLUDING (BUT NOT LIMITED TO) PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, 
LOSS OF USE, DATA OR PROFITS; OR BUSINESS INTERRUPTION HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
