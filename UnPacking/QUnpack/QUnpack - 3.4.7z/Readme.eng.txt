QuickUnpack v3.4 readme
========================

Description
-----------
The program is intended for a dynamic unpacking of binders, crypters, packers and protectors:

!EPack
!EProt
-=Protect=-
[CodeHider]
[R]ev Crypt
0LD G3N3R4T10N CRYPT
12311134
1337 Exe Crypter
1Way
2Ex Binder
2hC Executable Crypter
32Lite
7Cryptor
8Crypt XTreme
Aase
ABC Crypter
ABC Joiner
Abigor Crypter
Absinth Crypter
abstract
Acid burns Crypter
AcidCrypt
ACProtect
ACrypter
ActionCrypt
ActiveMARK
Adrenaline Binder
Advanced File Joiner
Advanced UPX Scrambler
AffilliateEXE
Affliction Crypter
afix!
Afx!AVSpoffer
AFX Executable Binder
Again Nativity Crypter
AGRockwiel crypt
Aholic Binder
AHPacker
AHTeam EP Protector
aiir.Crypt
aji cripther
AKI Crypter
Albertino Binder
ALDI Binder
Alex Protector
Alien Cryptor
Aliens Vs Depredator Crypter
ALL IN ONE Crypter Binder
Alloy
AlphaCodeCrypter
Alternate EXE Packer
Amok Joiner
Anadolu Crypter
ANDpakk
Angel's Crypteur
Anka Crypter
Anskya Polymorphic Packer
AnslymPacker
Anti Nod-32 Crypter
Anti Zort Joiner
Anti-Av Undetecter
Anti-Av.org Crypter
Anti007
AntiCrack Protector
AntiDote
antiOllyDBG
ap2k
APatch
AppPackager
aQa Crypter
AR Crypt
Archiless Crypter
AREA51 Cryptor
ArexX
ARM Protector
Arma X Crypter
Armadillo
AsCrypt
ASDPack
Ash Crypter
ASPack
ASProtect
ass-crypter
AsSaSiN CrYpT
Assassin Spread
AssassinCryptor
aSSBiNDER
Astaroth
Asvil Crypter
Asylum File Binder
AT4RE aSm Protecter
AuraCrypter
AuraStomper Crypter
Aurora Binder
aUs
AV Devil
AverCryptor
Avira AntiShit Crypt0r
Azazel binder
AZProtect
Azure's Packer
Azureus Crypter
B-ProTecToR
Ba5rosh DraGon Crypter
Backdoor PE Compress Protector
BamBam
Barredera Crypter
Basic Binder
Basic Crypter
Basic Pack
Bastards Tool
BCrypt
BeaCrypt
BEJoiner
Beria
Berio
BeRkk Crypter
BeRoEXEPacker
Best Crypter
Beta Crypter
Bifrost Crypter
BigCrypt
Billar Crypter
BiNaRi KRiP7OR
Bind That Shit
Binder Leopard
BinderSpy
Binding
BindIt
Biohazard Binder
Biohazard Crypter
BJFnt
bl0b Binder
bl0b Crypter
Black Crypter
BlackCore FileBinder
Blackout Crypter
Blade Joiner
BLCryptor
Bleeding Rose Crypter
Blinder join
BlindSpot
BLJoiner
Blood Crypt
Blue Rat crypter
BlueMorph
BmW Crypter
Bong Crypter
Bonsai Crypt
BopCrypt
Botijy Crypter
Boumedien CrYpT3R
BoxedApp
Break-Into-Pattern
BRM Crypt
Builder MVM
Bullet Crypt
C.I. Crypt
Cactus Metamorph
Camalion Crypter
Cannabis Crypter
Carb0n Crypter
CarbineCrypter
CCrypt
CD-Cops
CDS SS
Celsius Crypt
cEngine Crypter
CExe
Chameleon Packer
Chaos Crypter
Christmas-Crypt
CICompress
Cigicigi Crypter
City Fire Crypter
Clean Crypter
Client Crypter
Clone Crypter
Clown Crypter
Coco Crypter
Code Keeper
Code-Lock
Codebase Crypter
CodeCrypt
CodeSafe
CodingNation Crypter
Cold$eal
Colock
Colores Crypter
Colosus Crypter
CoMWell CrYpT3R
Conquista Crypter
Contego
CopyControl
CopyMinder
Countach
CPH CRYPTER
Crape Crypting Device
CrazyCrypt
Creative Coding Crypter
Cresta
Crestra
Crew Crypter
Crinkler
Crips0r
Cristmas Crypt
Crucified
CRUM Joiner
CRUM PolyCryptor
Crunch
CrypKey
Crips0r
Crypt Dmar
Crypt R.roads
CRYPT3R By L3GIONPR
Crypt4Free
Cryptable Seduction
Cryptador p0sion
CrypTalist
CrYpter [UXISAR]
Crypter Balta
Crypter By DsC
Crypter By Hacker59000
Crypter by Permabatt
Crypter by SLESH
Crypter By SuSo
Crypter By Vidson
Crypter Kpdo
Crypter Sr.1
CryptExe
Cryptic
Cryptit
Cryptix Binder
CrypTNT
CrypToCrack Pe Protector
CryptoFilez
Cryptonite
Cryptor SaudiHaCk
Cryptorious Crypter
Cryptosuite Crypter
Cryptosy
CRyptOZ
CryptWOZ
CryptX
Crypt[A3arTh]
Crypt[KZ]
CrypWrap
Crysis Crypter
CSDSJKK Protector
CuBe Crypt0r
CuCo Crypter
Cute j0!ner
Cyber-Sec Crypter
CyberCrypt
CyberGate Crypter
d0pe crypter
D1S1G
Dach-c[0]de
Daemon Crypt
DAEMON Protect
DalKrypt
Dark Ghotic Crypter
DarkAvengard
DarkCrypt
DarkMatrix Crypter
DarKoJa Crypter
Darkwar Crypter
Dayan Crypter
DB Crypter
DBPE
DCrypt
DDeM
Deagle Crypter
Death crypter
Deception
DEF
Dehombreadios Crypter
DelphBinder
demEnergy
Demon Binder
demXCryptor
dePack
Desert Scorpion binder
DexCrypt
DH Cripter
Diablo Crypter
Diamond Binder
DIET
DiGi-Binder
Digital Nemesis' Crypter
Dimon-z binder
Dimon-z Joiner
DirTy Cryptor
Disney On Ice crypter
Dive CryptOR
Djoiner
DK Binder
dl binder
DM Crypter
DNCrypter
DnKA Cryptor
DNSX Joiner
Donfelipe
dotFakeSigner
dpe
DPM CrYPT3r
Dr.House Crypter
Dr.True Crypt
Dragon Crypter
DragonArmour
Drony Application Protect
Droopy Binder
DsCrypTer
DSJoiner
DTCrypt
Dual�s eXe
DuneD Crypter
DW-Crypt0r
DWN Sbratta
DxPack
Dz-Crypter
Easy Packer NVC
Easy Binder
EasyCryptor
eblocrypt
EES Binder
Egy Crypter
El Bruto Crypter
ElecKey
Elite Packer
Elite Protector
Em0 CryPtEr
EmbedPE
EnCryptPE
Enginar Crypter
Enigma
Enigmas Crypter
EP Protector
Epeius Crypter
eS304
Escargot
Eset Nice Crypter
espatarramonjas crypter
EvilBinary
EvilCrypter
EvoLution bInder
Ex Binder
Excalibur
ExChain
ExCrypter
EXE,JPG File Binder
exe-joiner
ExE Evil
Exe Guarder
Exe in Exe joiner
EXE Lock
EXE Pack
EXE Password
EXE Protect
EXE Protector
Exe Stealth Packer
Exe Stealth Protector
Exe Wrapper
Exe32Pack
ExeBundle
EXECrypt
ExeCryptor
ExeDefender
ExeFog
ExeGriper
EXEJoiner
ExeJoinerTM
EXERefactor
EXESafeGuard
ExeSax
ExeShield
EXESmasher
eXPressor
eXtra Bind
Extra Element Crypter
Eye Crypter
EZIP
F.B.I.
FailCrypt
FakeNinja
Fakus Cryptor
Falckon Encrypter
Fallen Crypter
farbrauschPE
Fast File Crypt
Fatalz Crypt
FatMike
FBI Binder
FBinder
Fearless Bind
fEaRz Crypter
fEaRz Packer
Fender StratoCrypter
Feokt
Ferrari Crypter
FETiOP
fEvicol
fexx crypter
FFC
File Crypter
FileBind
FileJoiner
FilePacker
FileShield
Fire Joiner
FishPE
Fjuxs Binder
Flame Packer
Flash Crypter
Flashback Protector
Fly-Crypter
Forest Crypter
FProt
Franbv2009 & Leem Crypter
Franbv2010 Crypther
Frankenstein
Free Joiner Small
FreeCryptor
FreeJoiner
Freex64
FrenchLayor
Freshbind
FriCryptor
Frusion
FSG
FUCK AVIRA Simple Crypter
FuckIsrail Binder
Fud Crypter
Full Research Crypter
fUrIoUs Crypter
Fusion Auras crypter
FuzzBuzz Crypter
G!X Protector
G-CrYpT
G3 crypter
Gangsta TubbieS
GANTZ Crypter
GavnoCrypter
Gbind
GearCrypter
Gears Of War Crypter
Gentlemen Crypter
GhaZza CryPter
GHF Protector
Gie Protector
GioPacker
Gipson Polycrypt
GKripto
Gleam
Goats PE Mutilator
God Of War Crypter
Goku Crypter
Govnocrypt
Graveworm Binder
GSCryptor
GSJoiner
H.N.F Binder
H4ck-y0u.org Crypter
H4Ck|NG CRYPT3R
H7 Labz crypter
H7 Labz B1nd3r
HAC Crew-Crypter
Hacking.gvu.cc Crypter
HackOrDie Crypter
HackSecu Packer
Halloween Crypter
Halloween Packer
HaLV Crypter
Hammer Binder
Hanjian Packer
HAO Crypter
HardCore Soft BindeR
HaspSRM
Hat Crypter
Hatrex Cripter
HelioS-Binder
Hell Packer
Helminth Crypter
HH Binder
HH-Crypter
Hide Protect
HidePE
HidePX
HipACryp
Hiper_Crypter
Hipnosis Crypter
Hmimys Packer
Hombre Crypter
HoMeRo CrYpYeR
Hound Hack Crypter
HSN.C3r protector
Hyings PE-Armour
iBinder
Ice Binder
ICE License
IcebergLock
IcePoint Botnet Binder
iChipher
ICrypt
ID Application Protector
iEncrypt
IExpress
Ilusion crypter
IMP-Packer
IMPacker
Inbinder
INCrypter
Ind-Binder
Indetectables B1ND3R
Indetectables Crypter
Indetectables Protector
Indetectables X Crypter
iNF Cryptor
INF'[JOINER]
InFam0us Binder
Inferno's Crypter
Infinite Crypter
Infinity Crypter
InfinityJoiner
Ink Crypt
Interlaced
INV4S10N Binder
Invisus
Invius
Ipacker
iPBProtect
IProtect
Iron Crypter
iStealer
IzeL Crypter
J Multi Binder
J-BiNdEr
J8994's Basic Cryptor
Jah Rastafari Crypt0r
Jamaica Crypter
James's Crypter
Japabrz Cryptor
JasaHackBindeR
JDPack
JDProtect
JExeCompressor
JeyJey UPX Protector
JKymmel's Crypter
Jocker Crypter
JoDeDoR Crypter
Join It Now!
Joiner asd
Joiner By Spide
Joiner by Vayrus
JoinerCHK
JoinR
Joker Protector
Just Another PE Packer
K!Cryptor
KAERKRYPTER
Kaka Crypter
KaOs PE-DLL eXecutable Undetecter
Karcrack Joiner
KasperSky Pack
KByS
KenPack
Keton
Key Crypter
KGB Crypter
KGCrypt
KiAmS Cryptor
KiD Crypt
KiRoV Crypter
Kkrunchy
Kner Binder
Komputilo's Crypter
Kratos Crypter
Kriptirnik
Krypto Crypter
Kriptors
Krypton
kryptor
Kryptos
KsA Bind3r
Kur0k.X2.to
Kyubi Crypter
Kyzer23 Crypter
L-Pack
L1ght-Crypt3r
L1MIT Crypter
L3vel Crypter
LameCrypt
lARP
LC Crypto
Leaf's Crypter
Leem Crypter
LeetCryptor
Legal Joiner
LeM Crypter
Level-23 Crypter
Lexies Crypter
License Protector
Light Crypter
Lightning Crypter
Lightning Joiner
Lilith Crypter
Linkin Binder
LIPacker
LiQuid Vapour
Lite Binder
Lithius Crypter
LockDown Crypter
LOrD-Crypter
Lounger Crypter
LoVer hEx Crypter
LTC
Luck007
LuCypher
LulzCrypter
LuOpP Crypter
m3m0's Crypter
MadnessCrypter
Magic Binder
Mal Packer
Mala Semilla Binder
Manolo
manssion Crypter
MarCrypt
Maria Crypter
Marjinz Crypter
Masa Crypter
Mask Crypter
MaskPE
MassBinder
Mast3r-Crypt3r
Master Binder
Matrix Crypter
MBinder
McPhiros Guard Protector
MCrypter
mdCrypter
Metacrypt
MEW
MEWCRAP
Michael Jackson Crypter
MicroJoiner
Military Crypter
Mimoza
Mingo Crypter
Minguito Crypter
Mini crypter
Minke
MKFPack
Modbob Crypter
ModdedFog
Mole Spy
MoleBox
Money Crypter
Monkey Joiner
Morph�rypt
Morphine
Morphnah
Mortal Team Crypter
MoruK creW Crypter Private
Mota crypter
mPack
MPress
Mr Undetectable
MSLRH
Mucki's Protector
Multi Binder
Multi Packer
MultiCrypter
MultiMiniCrypter
Mu$hRo0M CryPt0R
MuRKRoWs Crypter
My PE Packer
MyCrypt
Mystic Compressor
MZ-Crypt
MZ0oPE
N-Code
N-Joy
NakedBind
NakedPacker
Narcis Crypter
Nathan Binder
nBinder
Ncorw81 Packer
NCPH
nCrypt
Nemesys Crypter
Neo Da Cryptor
NeoLite
Nephron Binder
NetCrypt
NetWalker
NewHacks Crypter
NEX Binder
NFO
NG Binder
Nidhogg
NightWolf Binder
Niller Crypter
NiNGiSHZIDA
NME
NNS Crypt
No_WaR Crypter
NOmeR1
NoNamePacker
NoodleCrypt
Nork Joiner
NoteCrypt
NovaCipher
noX Crypt
Noxious Binder
nPack
NsAnti
NsPack
NsPack Scrambler
NT Crypter
NTkrnl Packer
NTkrnl Protector
NtPacker
Nuevo crypter
NW Binder
NX PE Packer
Oasis Crypter
Obamas Binder
oBinder
Obsidium
Octopus
Octrix Crypter
OG-HiDER Crypter
OhShin Crypter
Old Dirty Bastard Crypter
Online Binder
Open Source Code Crypter
Optiikzz Crypt
Orbz Crypter
OrCrypt
Orien
OS Protector
OSC-Crypter
Overdoz
P.Q.P.I Joiner
p0ke Crypter
p0ke scrambler
Pack
Pack Master
PackItBitch
Packman
Pain Crew Protector
Pandora Crypter
Pantera Crypter
Password Protect UPX
PAV.Cryptor
PC PE Encryptor
PC Shrinker
PC-Guard
PCShrink
PE Crypt32
PE NINJA
PE Pack
PE Samourai
PE Shrinker
PE-Armour
PE-Hide
PE-Patcher+Cryptor
Pe123
PE32
PeBundle
PeCancer
PeCompact
PEcrypt
PEDiminisher
PEEncrypt
PegaSus Crypt3R
PELock
PELockNT
PEMangle
PEncrypt
PEnguinCrypt
PENightMare
Pepsi
PEQuake
Perplex PE-Protector
Personal Crypter
PESHiELD
PEShit
PeSpin
Pestil
PeStubOEP
Petite
PeX
PEZip
PFE CX
Phantom
PI Cryptor
Pimp Crypter
pitbull crypter
PKLite32
PlutoCrypt
PMSJoiner
Pohernah
Poisen Ivy Crypter
Poison Crypter
poket crypther
Polifemo Crypter
Poly!Crypt
PolyBox
PolyCrypt PE
PolyEnE
PolyMorPhic Xor Crypter
Porno Crypter
Power Crypt
Premium Crypter
Present Packer
Pretator Binder
Pribate
Private Exe Protector
Private Personal Packer
PrivateKrypt
PrivatePatcher
privet crypter
prjCone
ProActivate
Process Crypter
ProcessKill Crypter
ProCrypter
Program Protector
Prologue Crypter
Prosolution Crypt
Protect Shareware
ProtectDisk
Protection Plus
Prox Crypter
PS Crypter
pScrambler
Psycho Binder
Pub Crypter
PUNiSHER
PureBiND3R
PureCrYpT3R
Puri Crypt
PussyCrypter
PXCrypter
QrYPt0r
Quarantined Crypter
QuickPack
QwEErz BiNdEr
R-S Crypter
Rasmuz Crypter
RAT Packer
Rc4 Cryptor
RCryptor
RDG Pack
RDG Tejon Crypter
RealCrypt
Reaper Crypter
ReCrypt
Red Dev1L Crypter
RedbindeR
ReDiX Crypter
redlight_crypt
Reductor
Refruncy Crypter
RekCryter
Relva Crypter
Rephlex Binder
Represent Of Indetectables
ResCrypt
Revelion Joiner
ReversingLabsPack
ReversingLabsProtector
Revolu-Encriptor
RevoluPimp Crypter
RianTR Proctector
Rio 2016 Crypter
Ripped Crypter
RJoiner
Rockito crypter
Rocko Crypter
RogueCrypt
RoguePack
Rose Cryptor
Royal Crypter
RPolyCrypt
Rub3
Rubbish
rude surprise binder
RunCrypt!
RunPE Killer
Russian Cryptor
S-A-H
Saddam crypter
Sanlegas Crypt3r
Saudi CrYptOr
SBinder
SC Obfuscator
ScanCryptic
Scantime Crypt0r
SCB Lab's Crypt0r
SCB Lab's Joiner
SCD [binder]
SceneCrypt
Sch...
Schattenreich Crypter
School hack CrYpTeR
Schwarze Sonne Crypter
Scofield's Cryptor
SCPack
Scramble Tool
SCrypt
SD Crypter
SDProtector
SecuPack
Secure Crypter
Secure Shade
SecurePE
SecureWorld Binder
Selassi Binder
Self Decrypting Binary Generator
Sell Crypter
Seritx's Crypter
Sexe Crypter
SexyPacker
SFJoiner
Sh!T BindeR
Sh7bor Binder
Shadeh4Ck Crypter
SHADeR
Shadow Crypter
Share Crypter
SharKCrypter
Sharki Crypter
Shegerd Exe Protector
Shikamaru Crypther
Shimmi Crypter
ShimpRun Binder
Shitty Binder
Shlapo Joiner
SHNi Joiner
Sh0ck Packer
ShockLabs File binder
SHProtector
Shrinker
Shrinkwrap
Sickrypter Mini
Sikandar�s Crypter
SilkRopeBind
Silly Chr Encrypter
Sim Crypter
SimbiOZ
Simple Binder
Simple Crypter
Simple Pack
Simple Strreverse Encryption
Simplicity Crypter
Sin Nombre
SINCrypter
Sixxpack
Sk1D Crypter
SkD Undetectabler
skorpien007 crypter
Skull Crypter
SkuLLByte Crypt
Sky Crypt
Sky Protector
SKYSAN CrYpTeR
slackpack
Slave Binder
slickpack
SLVc0deProtector
Small Crypter
Small joiner
Small Polymorphic Crypter
SmokeScreen Crypter
SmokesCrypt
sNaKe CrYpTeR
Snoop Crypt
SoftProtect
softSENTRY
Software Compress
SOLEid
SOLiD Binder
Sopelka
Soprano Crypter
Sora Crypt
South Park Crypter
Sp1r1tus binder
Sp1r1tus joiner
Sp4|N--CryPt3R
Space Crypter
SPEC
Special EXE Pasword Protector
SpeedCrypter
Spider Binder
Spider Packer
Spirit's Packer
SPLayer
Splitter
Spread Crypt
Spy Crypter
SqUeEzEr's Crypter
ST Protector
StarForce
StasFodidoCryptor
Ste@lth PE
StealTh TooL
STL Packer
STL WebDownloader
Stone's PE-EXE Encrypter
Stonedinfect Crypter
Storm Cryptor
StrAnGe CrYpTeR
StRaXxXD Binder
STUB
Style'S Crypter
submarine-rat.com crypter
SunS Joiner
Sup Crypter
Super Binder
SupEr CrAzY
Super Fast File Binder
Super glue for EXE
SuperCrypt
SuperPacker
SuSoO Crypter
SVK Protector
SyCo Packer
Sylar crypter
SyMoH Crypter
SynBinder
SynPacker
t0r Bind
TableCrypt
Tages
TAI 42 Crypter
Tarex Crypter
Taurus Protector
Tejon Crypter
tElock
TetraPack
TGR Crypter
TGR Protector
Tha BOO CrypterR!
The Art Of Deception
The Best Cryptor
The Cood's Crypter
The DeaD B!nDer
The Fuckin Oresme Binder
The Gathering Binder
The Little Crypter
The Zone Crypter
Themida
Themis Binder
Thinstall
Thunderbolt
Tiburon Crypter
tikkysoft joiner
Tiny crypter
Tiroloko Crypter
TiXor b!nder
TNT Crypter
toMcrypT
ToP GUI Full
Toy Joy
TPPpack
Trance Crypter
Trendy Nigger Binder
Tribal Crypter
TrickySigner
Triforce Crypter
Tripex Crypter
Triple X Crypter
Trojka Crypter
TrueEP
TrurghyBinder
TsT Binder
TsT Crypter
Tubby Crypt
Turkish Cyber Signature
Turkojan Binder
Turkojan Crypter
twinkle crypt
TYV Crypter
uBinder
UFO Crypter
UG Chruncher
Ultimate Sharingan Crypter
UltraProtect
Under S3H Protector
UnderGround Crypter
Undetected
Undetector
UnDo Crypter
UniProtect
Universal Crypter
uNk Binder
uNk Crypter
unkOwn Crypter
UnLimited Crypter
unNamed ProTector
unnamed Scrambler
UnOpix
UnOpixScrambler
UPack
uPack Mutantor
Upc
UPolyX
UProtector
UPX
UPX Crypt
UPX Cryptor
UPX Inkvizitor
UPX Lock
UPX Mutanter
UPX Protector
UPX$hit
UPX-Scrambler
UPXFail
UPXFreak
UPXRedir
UPXScramb
US Crypter
Useless Binder
Useless Crypter
USSR
vaCipher
Vampir Crypter
VB-PE-Crypt
VB-PowerWrap
VBC Crypt
VBC Joiner
VBEXEObfuscator
VBOWatch Protector
Vbs Encrypter
VCrypt
Vegan Crypter
VGShrink
Victoria Crypter
Viking Crypter
Viotto Binder
ViroGen Crypt
Visual Protect
Vlz
VMProtect
VPacker
VT FucKer
Vuvuzela Crypter
VXPack
Wally Crypter
Weekend Binder
Werus Crypter
Wh1t3bird Protector
White widdow
WhiteEye Crypter
Whitell Crypt
Wind of Crypt
Window crypter
WingsCrypt
WinKrypt
WinLicense
WinLite
WinUpack
WL-Crypt
Wolf Crypter
WouThrs EXE Crypter
Wrapper
Wretch-x Crypter
WTF Crypter
WWPack32
X-Crypter
X-ExeJoiner
X-files Crypt
X-N2Binder
X2binder
Xa0s Joiner
xAVx Crypter
XComp
XcR
xCrypt
xdz-Crypter
xebroom
xHacker Crypter
XPack
Xpro Crypter
XXPack
Xypt Crypter
Yeah Blinder
Yet Another Binder
yet another useless crypter
YinCrypt
Yoda's Crypter
Yoda's Protector
Yokoh Crypter
Yorllcito Crypter
Yoshistr Crypter
YZPack
YZProtector
Z04 Crypter
ZeldaCrypt
ZeroCrypter
ZipWorx SecureEXE
Zombie's joiner
ZProtect
ZXCriptor
ZXProtector
Zylom Wrapper
------------------------------
1210 known binders, crypters, packers and protectors and many others...

x64 version successfully tested on:

Armadillo x64
MPress x64
NsPack x64
PeSpin x64
VMProtect x64

QuickUnpack tries to bypass all possible scramblers/obfuscators and restores redirected import. From the version 1.0 the opportunity of unpacking dll is added. From the version 2.0 the attach process feature added which allows to use QuickUnpack as a dumper and import recoverer. Scripts are also supported from version 2.0 which allows unpacking of more complicated protections. This makes QuickUnpack a unique software product which has no similar analogues in the world!

Use force unpacking tick. When the application is run QuickUnpack waits for the OEP breakpoint to trigger. But sometimes this breakpoint may be triggered several times but only the last one is the correct OEP. Using ForceMode option solves this problem. With this option after the application is run QuickUnpack counts breapoint hits and dumps the application only at the last stop. For DLL-files this option is always ticked and allows to restore relocs.

If you have any suggestions or found any bugs please tell me about them. You can find me at cracklab.ru forum or exetools.com forum or tport.org forum or you can find me at irc://irc.street-creed.com:6667 at #tport

The license and rights
----------------------
The list of sources used in coding QuickUnpack:
stripper asprotect unpacker by syd
PEiDLL.dll by Bob
GenOEP.dll by Snaker
disassembler by Mikae
Marquee creeping line by Funbit/TSRh
plugins and some other code by NEOx
MiniFMOD by Firelight Technologies
the SEException code by Martin Ziacek
Picture (Implementations) by Dr. Yovav Gad
for OEP finders the author is mentioned in the program
Lua scripting language from http://www.lua.org

History of the versions
-----------------------
v3.4
[!] fixed several bugs and made improvements
[!] QU now tries to use old IAT at first
[!] completely rewrote Force OEP finder
[+] all direct import references are processed now, not just call xxx/jmp xxx
[+] Time delta can be automatically calculated
[+] many header fields are now recomputed, almost all the header is rebuilt
[+] updated generic OEP finder by Dilla
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts
[-] ImpRec compatibility is now broken
[-] removed protection identifiers

v3.3
[!] moved to Visual Studio 2008 SP1
[!] fixed several bugs and made improvements
[!] driver name, service name and symbolic link are now randomly generated
[!] refactored the engine and made it 1.5 times faster
[+] path building for import libraries added
[+] export table rebuild ability added while cutting sections
[+] log autosave ability added, logs are written into Logs folder if strings>5000
[+] updated generic OEP finder by Dilla
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.2
[!] fixed several bugs and made improvements
[!] rewrote driver a bit to avoid synchronization bugs
[!] completely rewrote deroko's OEP finder to make it faster and more stable and make it work under x64. sometimes doesn't work under virtual machines
[!] completely rewrote Human's OEP finder to make it work under x64
[!] completely rewrote UsAr's OEP finder with LaZzy to make it work under x64
[!] took a completely new disassembler now also available under x64
[!] x64 version is completely finished with all the functionality
[+] added new generic OEP finder by Dilla
[+] forwarded import functions are now processed automatically
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.1
[!] fixed several bugs and made improvements
[+] enlarged protectors list
[+] sound engine changed to MiniFMOD 1.70. after a day of fucking it also began to work on x64
[+] added several new functions and variables for the scripts

v3.0
[!] fixed several bugs and made improvements
[+] 14.09.2008 x64 version was born
[+] 06.11.2008 the first x64 file was unpacked
[+] enlarged protectors list
[+] updated ufmod to 1.25.2a
[+] added several new functions and variables for the scripts

v2.3
[!] decided to make this private. If you're reading this, I guess you're one of the guys whom I trust, don't fail me
[!] fixed several bugs and made improvements
[!] the program is divided into sections correctly, access attributes and names are added
[+] updated Lua to 5.1.4
[+] added ability to manually choose RVA to cut sections at
[+] significantly enlarged protectors list
[+] added several new scripts
[+] added several new functions and variables for the scripts

v2.2
[!] fixed several bugs and made improvements like quickened import processing
[+] RDTSC delta also affects GetTickCount now
[+] updated Lua to 5.1.3
[+] updated UsAr's generic OEP finder
[+] modified Human's generic OEP finder to find OEP in DLLs
[+] modified deroko's generic OEP finder to find OEP in DLLs
[+] added Save log feature to the main menu
[+] added support of different languages, just create your own lng-file and enable it at the preferences window
[+] added delphi initialization table restoration. Be sure to turn this on only for Delphi programs
[+] finished the work on the memory manager which allows to collect all the allocated memory into one image (private version only)
[+] added several new functions and variables for the scripts
[+] changed a bit RDTSC hook. if the most significant bit is set in delta QuickUnpack calculates the delta itself

v2.1
[!] fixed many bugs like crash on some applications while restoration of resources
[!] multithreaded applications are now handled properly
[+] added ability to set end of module when tracing import functions. When a reference to import is found it's analyzed if it leads to some space outside of the module (not to trace some internal functions). But some packers redirect import to the last section. This option is intended to aid this problem. This is RVA
[+] added ability to put import table at given RVA instead of adding extra section
[+] added ability to set RDTSC delta for RDTSC hook (see more on rdtsc_delta in Scripts.eng.txt)
[+] Load libraries only option added to import recovery methods. this option doesn't actually recover import it just puts 1 import function from every loaded DLL into the import table. thus dump will be loaded with all the necessary libraries and will use old addresses for import functions which were set by a protector. this option can be used if import redirection is too complicated but the dump will stop working after service pack or some other patch installation
[+] Execute functions while tracing import option is added. by default while tracing import functions are not executed but some protectors need result of these functions to operate correctly so this option can be used
[+] Process call xxx/jmp xxx option is added. some protectors change import calls and jumps from call [xxx]/jmp [xxx] to call xxx/jmp xxx. this option is intended to work also with these redirections
[+] added several new functions and variables for the scripts
[+] UsAr's generic OEP finder now supports DLLs
[+] new Vista manifest added

v2.0 final
[!] fixed many bugs like missed import functions
[!] fixed several driver bugs like the one which didn't allow to pass some exceptions
[!] improved export feature now supports invalid functions
[!] many improvements (like 256x256 icon for Vista, thanks to Feuerrader :)) and optimizations (like better memory handling)
[!] now Force.dll doesn't use GenOEP.dll, though some code was borrowed
[+] added so long-waited ability to use scripts. before using scripts it's strongly recommended to read the manual (Scripts.eng.txt file). script examples may be taken from Scripts folder (*.txt files), scripting language Lua manual also can be found there (Lua Manual.html), which parser was embedded in the program. BTW I know that Step button doesn't work like a charm but I wasn't able to make it better
[+] passing parameters to the application added
[+] import list from ImpRec feature added (now QuickUnpack supports both export and import of import functions in ImpRec-compatible files this allows to edit some functions or add new ones. keep in mind this option works with normally created files but if you put some garbage or format this file in unusual manner this may cause crash :) I was too lazy to parse the file with care)
[+] attach process feature added (this option allows to choose any module in a process for unpacking and has some features. if in processes listbox a process name is a full path with name you can attach to this process. if it is only name of the file you don't have enough rights to attach. you can't specify the OEP, the instruction the program was stopped is treated as the OEP. to use attach process feature one should load the program in any debugger and manually get to the OEP, when attach to that process with QuickUnpack. keep in mind that for smart import recovery you don't need the program to run, it can just be left in the debugger standing at the breakpoint. but to use smart import recovery with tracer you should put it in the infinite loop (EB FE) and run the program because the tracer uses current thread for tracing. if the program was put in the infinite loop don't forget to restore these two bytes in the dump. when attached tracing import is unreliable and very slow, so it's not recommended to use it). this feature allows to use QuickUnpack as a dumper and import recoverer (my attempt to replace PETools and ImpRec with one program :))
[+] ImpRec plugin support added (this feature allows to use ImpRec tracer plugins in QuickUnpack to restore import functions. keep in mind when using attach to process feature the program must be run for the tracer to work)
[+] added UsAr's generic OEP finder. I modified it a bit
[+] added Human's generic OEP finder. I modified it a bit
[+] added deroko's generic OEP finder. I modified if a bit and took the GUI from Human's generic OEP finder. it's sometimes slow but rather powerful and be warned that this finder uses driver and the driver is unloadable till next reboot. uses deroko's Dream of every reverser engine so incompatible with win2k3 and kaspersky. for more information about this engine visit http://deroko.phearless.org
[-] no more old non-generic OEP finders

v1.0 final
Unfortunately Feuerrader has left this project, so from now on I'm (Archer) is the only developer.

[!] several bugs fixed like possible tls corruption when removing sections or possible program crash when reading false relocations
[!] identifies dll according to the flag in the header instead of the extension
[!] improved import tracer doesn't fail to trace emulated functions
[+] overlay append option added
[+] ability to disassemble import functions (if some function was emulated you may use this to identify the function)
[+] ability to add new library (allows to use import functions from the new library when editing import functions. also while loading the library the program stands at the OEP, so you can use your own library to do something with the import or with the program)
[+] ability to edit import functions (allows to fix some import functions by hand. the edit window supports typing function's name on the keyboard along with the choosing it in the listbox)
[+] option to add suspicious functions (allows to add possibly emulated functions to the import table to fix them by hand later using new feature above. be warned that false functions may be also added and they must be removed)
[-] no more ImpRec.dll (this method was rather buggy, others methods are more powerful, so I decided to remove this one)

v1.0 RC1
[!] Sections are truncated properly
[+] New feature - resource rebuilder and tracer (restores redirected import)! Now it handles simple protectors, ex. Yoda Protector
[!] Critical errors are now reported
[!] Get unloaded properly after crash
[!] Some bugfix and optimized code
[!] Fixed ImpRec method
[!] Fixed Force Mode
[!] The driver has been rewritten with improved rdtsc emulation and changed breakpoints   

v1.0 beta8 [!] Bug fixed with Always on top option
	   [!] Bug fixed with BSOD and unterminated processes
	   [!] Optimized import recovery by syd's method
	   [+] Added export import tree to ImpRec
	   [+] Updated engine.sys
	   [!] Bug fixed with dll unpacking
	   [!] Bug fixed with old upx versions on dll
	   [!] Kill target button works correctly now
	   [!] View of import table was changed
	   [!] Find object button added

v1.0 beta7 [+] Improved interface
	   [+] Fixed small bugs

v1.0 beta6 [!] Internal build

v1.0 beta5 [+] Support of unpacking UPX 2.0
           [+] New signature list
           [+] New engine from stripper 2.13 b9

v1.0 beta4 internal [!] bugfixes

v1.0 [+] an opportunity of unpacking dlls is added
     [+] an opportunity of using plug-ins and own OEP finders is added

v0.7 [!] Based on updated stripper 2.11 rc3 engine => new features
     [+] Force mode added v0.6 [!] Final build
v0.5 [+] QuickUnpack now uses new engine and works through external tracer engine.sys. No debug API is used
     [+] Dump and PE header are very clean after unpacking
     [+] Cool OEP finder for packers
v0.43. [+] The opportunities of ImpRec.dll were added. It will be useful, I think
       [+] Protection from IsDebuggerPresent was added (a tick "Hide unpacker")
       [!] This version is last, I think, as the opportunities of Debug API are fully used

v0.41. [!] Fixed the bug with the unpacked programs compatibility on the different OS (the bug with RestoreLastError)

v0.4 final. Final build. All the mistakes were fixed

v0.3. [+] The engine working with the dump is completely re-coded
	  Now the engine from PE Tools by NEOx [uinC] is used
      [+] The system of "clever" dump rebuilding and optimizing its size is supported
	  The engine of the dump rebuilding from PE Tools by NEOx [uinC] was used
      [!] Picture of QuickUnpack was removed :) 
      [+] Packers with damaged headers (e.g. FSG) are supported
      [+] The bugs in the operations with PE files were fixed

v0.2. The first version. All as is

Greetz and thanks
-----------------
tPORt, AHTeam, TSRh, KpTeam, REVENGE, CRACKL@B, ICU members, CoaxCable^CPH, Wild-Wolf and all CPH members on #cph, LaFarge[ICU] and SofT MANiAC for nice music, SergioPoverony, DillerInc, newborn for logo, syd, lord_Phoenix, NCRangeR, Grim Fandango, Aster!x, Quantum, MozgC, Sten, PolishOX, NEOx, WELL, GPcH, Funbit, sl0n, Ms-Rem, Bad_guy, dj-siba, =TS=, DillerInc, UsAr, Human, deroko, Errins, Bronco, HandMill, Executioner, 4kusN!ck, BiT-H@ck, Hellsp@wn, HoBleen, Smon, LaZzy, Mikae...