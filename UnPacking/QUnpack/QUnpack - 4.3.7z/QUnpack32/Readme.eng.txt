QuickUnpack v4.3 readme
========================

Description
-----------
The program is intended for a dynamic unpacking of binders, crypters, packers and protectors:

!EPack
!EProt
$imples Protector
-:die595:-
-=Protect=-
...YGD... Crypter
01 - Crypter Au3
0LD G3N3R4T10N CRYPT
0nLy Crypter
1
12311134
1331 lol1
1337 Exe Crypter
1Way
2012 Crypter
2Ex Binder
2hC Executable Crypter
2Pac Crypter
32Lite
3D Cript
4n0nym0us Crypter
7Cryptor
7H3 D3V1L CR1P7
8Crypt XTreme
:) Crypt
? Crypt
[C]orp-51 [C]rypt0r
[CodeHider]
[Crypter Simples
[I]ndetect [C]rypt
[KIll] Crypter
[KIll] Crypter 2.0
[KIll] Crypter 3.0
[KIll] Encryption
[Large] [Crypt3r]
[Link Park] Crypter
[M] Crypt
[R]ev Crypt
[W]HITE~[R]00T Easy Crypter
\\CrYpT3d
_MGS_Solid_Snake_ Crypter
~Simple Crypter~
A286
Aase
Abastract Green Binder
ABC Crypter
ABC Joiner
Abella Anderson
Abella Anderson Crypter
Abigor Crypter
Absinth Crypter
abstract
Abstract Fantasy
Ac.MiLan Crypter
ACDC CRYPTER
Acid burns Crypter
AcidCrypt
ACProtect
aCrypt
ACrypter
ActionCrypt
ActiveMARK
adeanna-cooke
Adrenaline Binder
Advanced File Joiner
Advanced UPX Scrambler
AffilliateEXE
Affliction Crypter
afix!
Afx!AVSpoffer
AFX Executable Binder
Again Nativity Crypter
AGRockwiel crypt
Aguante Central
Aholic Binder
Ahorrador Crypter
AHPacker
AHTeam EP Protector
aiir.Crypt
AirbournE Crypter
AJaN
AjY Crypter
Ak Crypter
AKI Crypter
Akrapovic AutoIt Protector
Akripter
Albertino Binder
ALDI Binder
Aleatorio
Alex Protector
Alexandra Stan
Alicia Machado Crypter
Alien
Alien 3
Alien Crypter
Alien Cryptor
Aliens Vs Depredator Crypter
ALL IN ONE Crypter Binder
Alloy
Alonso 2010 Crypter
AlphaCode Crypter
Alternate EXE Packer
Amazon Crypter
American Sex Crypter
Ammo_Crypter
Amok Joiner
Ana Celia de Armas Crypter
ANA SIMOM
ANA SIMON
Anadolu Crypter
ANDpakk
Andrea Rincon
anexuscrypt1
ANGEL CRYPTER
Angel Crypt Evil
Angelus Apatrida Crypter
Angel's Crypteur
ANIME CRYPTER
Anka Crypter
ANONIMOSX
anonimosx_SimpleCrypter
Anonymous
Anonymous Brasil
ANONYMOUS CRYPTER
Anonymous Crypter
Anonymous Crypter v2
ANONYMOUS JOINER
Anotador
Anskya Polymorphic Packer
AnslymPacker
Anti Nod-32 Crypter
Anti Zort Joiner
Anti-Av Undetecter
Anti-Av.org Crypter
ANTI-PARAGUAS
Anti007
AntiCrack Protector
AntiDote
Antifascismo Crypter
antiOllyDBG
Anubis Crypter
ap0x crypter
ap2k
APatch
AplastAvs Crypter
Apocalypse Crypter
apocalyptic world of fire
Apollo protector
Apple Cryptor
AppPackager
aQa Crypter
Aqua-Draco Crypter
AR Crypt
Archiless Crypter
Arco Crypter
AREA51 Cryptor
ArexX
Argentina Protector
ARM Protector
Arma X Crypter
Armadillo
Army Girl Crypter
Army Of Two Crypter
Arnold Classic Brasil 2014 GIRL
Arnold Criting
ARTAN Protector
Arthur Rimbau
Arthusu Crypter
ArYit Radar
AsCrypt
ASDPack
Ash Crypter
ASH-LAB Crypter
Asian Crypter
ASimple Crypter
ASPack
ASProtect
ass-crypter
AsSaSiN CrYpT
Assasin's Creed Crypter
Assassin Spread
AssassinCryptor
Assassins Creed Crypter
Assassins Creed Revelations
aSSBiNDER
Astaroth
Asterix
Asvil Crypter
Asylum Crypter
Asylum File Binder
AT4RE aSm Protecter
AtomCrypt
Au3 Crypter
AuraCrypter
AuraStomper Crypter
Aurora Binder
Aurora Crypter
aUs
Auto-12/12/12 Crypter
AV Devil
Ava$t Crypter
Avast
Avast Protector
Ave Fenix Crypter
Avenged Sevelfold Crypter
Avenger Simple
AveProtector Crypter
AverCryptor
Avira
Avira Free Crypter
Avira sHit
Avirita no estaba muerto Ahora estas
AVS BRUTAL MURDER
Avs Fucks
Azazel
AZProtect
Azure's Packer
Azureus Crypter
B-ProTecToR
Ba5rosh DraGon Crypter
BABA MENGENE BINDER
BABA Private All in One
BackBreaker
Backdoor PE Compress Protector
Backtrack_cryp
Baku# Crypter
Ball 3D Crypter
Balon Crypter
BamBam
Bandana Crypter
Bandook Crypter
Banfield Crypter
Bang Bang Estas Liquidado Crypter
Baphomet
Barca Crypter
Barcelona Crypter
Barney Stinson Crypter
Baron Rojo Crypter
Barredera Crypter
Bart Crypter
Basic Binder
Basic Crypter
Basic File Binder
Basic Pack
BasicCrypter
Basicuzinho Crypter
Bastards Tool
Batalla Naval
Batman Crypter
Battleship Crypter
BCrypt
BeaCrypt
Beatiful Crypter
BEJoiner
Beria
Berio
BeRkk Crypter
BeRoEXEPacker
Best Crypter
Best FUD Crypter
Bifrost Protector
Big 4 Crypter
BigCrypt
Billar Crypter
Bin Laden Crypter
Bin4r0 PROTECTOR
BiNaRi KRiP7OR
Binary Crypter
Bind That Shit
Bind Them Into Darkness
Binder
Binder adwind
Binder and Crypter
Binder AutoIt
BINDER BY TOMJOSE
Binder Homenaje a El Chavo del Ocho
Binder Leopard
Binder Multi-Extension
Binder Paloma
BindeRCN
Bindern jpg
BinderSpy
Binding
BindIt
Bindosni
BiO Hz Crypt3r
Biohazard Binder
Biohazard Crypter
Bird of Fire Protect
Birulana Fire
Bit CRYPT
BIT_CRYPT
Bizzy Bone
BJFnt
Bl0b B!nder
Bl0b Crypter
BLACK cryp
BLACK crypt
Black Crypter
Black Eye
Black eyes Crypter
Black Form1 Simple
BLACK LABEL CRYPTER
Black Rock Shooter Crypter
Black-butterfly crypt
Black_CRYPT
BLACK_CRYPTER
BlackCore FileBinder
BlackMaster Crypter
Blackout Crypter
Blade
Blade Joiner
BLCryptor
Bleeding Rose Crypter
Blinder join
Blinder-Joiner
BlindSpot
BLJoiner
Block's Krypter
blood Cript
Blood Crypt
BloodSeeker Crypter
Bloody
Blue Crypter
Blue Gladiator Crypter
Blue Rat crypter
BlueMorph
BmW Crypter
Bob Marley Protector
Boca Cerrada Crypter
Bombastic Crypter
Bombon Crypter
Bong Crypter
Bonita colita Crypter
Bonsai Crypt
Boom Crypter
BopCrypt
Boredom Crypter
Botijy Crypter
Boumedien CrYpT3R
BoxedApp
Boxing Crypter
Brasil 2014 Crypter
BRASIL CRYPTER
Brasil Crypter
Brasil FUD
BRASIL VS ESPANA
Brasil X Colombia
Brasil x Mexico
Brasilean Crypt!
Bravus Crypter
Brazilian Sexy Chick Crypter
Break-Into-Pattern
BreakingBad Crypter
BRM Crypt
Broly Crypter
Bruce Lee Crypter
Bubbles Crypter
Buen Porrazo Crypter
Buena Muerte
Buena Vibra Crypter
BugCrypter
Builder MVM
Bullet Crypt
Bullet For My Valentine Crypter
BullGuard Crypter
Bunda Brasileira
butterfly Dark crypter
BYE MANCO CRYPTER
ByPiT Crypter
C Crypt
C.I. Crypt
c9Crypter
Caballeros del Zodiaco
Caballo Crypter
Cache Crypt
Cactilio - Joiner
Cactus Joiner
Cactus Metamorph
Cactus VBS Crypter
Calavera Crypter
Call Of Dutty Black OPS II
Call of duty black ops II Crypter
Call Of Duty Ghosts
Call Of Duty M4W
Camaleao Crypter
Camaleon Crypter
Camaleon Killer
Camaleoncito Crypter
Camalion Crypter
Cambio de nombre Crypter
Cameltoe Crypter
Camuflaje
Camuflaje Simple
Canabis Crypter
CANALLAMAN Crypter
CaNaLLaS Crypter
Cannabis Crypter
Capitan Jack Sparrow Crypter
Carancho Crypter
Carb0n Crypter
CarbineCrypter
Carlos Melconian Crypter
CASTIGOL Crypter
Cat Crypter
Cavala Crypter
Caveira_CRYPT
CB Crypter
CCCP Crypter
CCrypt
CD-Cops
CDS SS
Ceifeiro_CRYPT
Celsius Crypt
cEngine Crypter
CeoCrypt
Cesar_33 Crypter
CExe
Chameleon Packer
Chaos Crypter
Chaotic Crypter
Charley Crypter
charlize theron
Chaso Crypter
Chavez Crypter
Chavez y Conpatriotas Crypter
Che Guevara Crypter
Chica Brasilena
Chica Linda
Chica Sexy
Chinita Crypter
christina scabbia
ChristmaS LinuX
Christmas-Crypt
Chrome Crypter
CICompress
Cifrador
Cigicigi Crypter
City Fire Crypter
Clarion Crypter
Clean Crypter
Client Crypter
Cliente Toma2
Clone Crypter
Close Light Crypter
CloudCrypt Ave Fenix
CLOUND RENDER
Clown Crypter
CMD Crypter
Cobra Crypter
Cocaina Crypter
Coco Crypter
Code Keeper
Code-Lock
Codebase Crypter
CodeCrypt
Codelux Crypter
CodeSafe
CodingNation Crypter
Cold$eal
Colita Sexy
Colock
Colombia Crypter
ColomBia CryptR
ColomBian CryptR
Colon Crypter
Colores Crypter
Colosus Crypter
Combate Naval de Iquique
Compilation
ComradeX Binder
ComradeX Crypter
CoMWell CrYpT3R
Conejita Crypter
Conejon DSR! Crypter
Cono Crypter
Conquista Crypter
Const Crypter
Contego
Cool_Crypter
Cool_Floyd
CopyControl
CopyMinder
Corinthians Crypter
Corp-51 Crypter
Corp_51
Cosmo Crypter
Countach
Counter Strike Crypter
Courtney Cox Crypter
CowGirl Sexy Crypter
CPH ~ CRYPTER
Cr!tBinder
Cr1pT3r....
Crack Family Crypter
Craneo Crypter
Crape Crypting Device
Crawling Crypter
Crazy Crypter
crazy mouse BINDER
CrazyCrypt
Creative Coding Crypter
CRELORD
Cresta
Crestra
Crew Crypter
CrimeBind
Crinkler
Crips0r
cripter PEPINO
CripTNT
CRISTIANO RONALDO CRYPTER
Cristina Pedroche Crypter
Cristmas Crypt
Cristo Crypter
Crucified
CRUM Joiner
CRUM PolyCryptor
Crunch
Cruz Diablo
Cruzeiro Mejor Time
CRYP BY SUDO
Cryp Private
Cryper Sencillo
CrypKey
CRYPO CRYPTER
Crips0r
Crypt
Crypt Dmar
Crypt E'm
Crypt Fast
Crypt R.roads
Crypt *-*
CRYPT -.-
Crypt'Oijkn
CRYPT_BY_SUDO
crypt_by_sudo
CRYPT_O1_BY_SUDO
Crypt0r
CrYpT3R
Crypt3r
CRYPT3R By L3GIONPR
Crypt3r Eyes
Crypt4Free
Cryptable Seduction
Cryptador p0sion
CrypTalist
CryptCrew Crypter
CRYPTER
Crypter
crypter
Crypter #3
Crypter *** Adrive
Crypter [Himanen]
Crypter [MaMoN]
CrYpter [UXISAR]
Crypter 1 so caminho
Crypter Abstract
Crypter ADN
Crypter Aguila
Crypter Alien
Crypter Aline
Crypter Andressa Soares
Crypter Angel
Crypter Anime
Crypter Anonymous
CRYPTER ANTARES
Crypter Anti-Sopa
Crypter Arbol Solitario
Crypter Artistic
CRYPTER ARTISTIC PURE EDITION
CRYPTER AU3
Crypter Azul
Crypter Baku
Crypter Balta
Crypter Batman
Crypter Beta
Crypter Binary
Crypter Black list
CRYPTER BLACK SABBATH
Crypter Bleach
CRYPTER BOB MARLEY
Crypter Borges & Boy
Crypter Bruce Lee
CRYPTER BUENOS AIRES
CRYPTER BUSCANDO A NEMO
Crypter Buscando el Tesoro
CRYPTER BY BDWONG
Crypter by charley
Crypter by DollyDolly
Crypter By DsC
Crypter By Hacker59000
Crypter By Josera
Crypter By Naker90
Crypter by Permabatt
Crypter by rhector123
Crypter by SB
Crypter by SLESH
Crypter By SuSo
Crypter By Till7
CRYPTER BY TOMJOSE
Crypter By Vidson
Crypter by_SB
Crypter Castillo del Huevo
Crypter Chaves
Crypter Colors
Crypter Comando Vermelho
Crypter ComentaCabron!
Crypter Css
Crypter Daft Punk
Crypter Danger
CRYPTER DARKCOMET
CRYPTER DEDICADO A
Crypter Dekoders
Crypter Dj
CRYPTER DONCELLA
Crypter DRAG&DROP
Crypter DRAG&DROP HAUNTER
Crypter DRAG&DROP MINION
Crypter Dragon Ball
CRYPTER EAGLE PROTECTOR
Crypter Endorphine
Crypter Evil Red Eyes
CRYPTER FACiL
CRYPTER FANTASY
CRYPTER FANTASY II
Crypter Feliz Natal 2012
Crypter Feliz pascoa For all
Crypter Ferrari
Crypter FireBurn
Crypter Fito02 & Dj Qitin
Crypter Fuck Avira
Crypter FuckNod32
Crypter FUD Privado
Crypter FueGo
Crypter Fumancha
Crypter Generator
CRYPTER GOD OF WAR ASCENSION
CRYPTER GOOGLE
Crypter h4ckv2
Crypter Homer
Crypter Indetectable
Crypter Indetectables.net
CRYPTER IRON MAN
Crypter JabbaWockeeZ
Crypter Joker
Crypter k7
Crypter Kpdo
Crypter La Etnnia
Crypter Lamborgini
Crypter Leopard
Crypter Leopardo
CRYPTER LEVEL-23
CRYPTER LOLLAPALOOZA
Crypter Luana Kisner
Crypter LUFF
Crypter M4sk
CRYPTER MAJYX SCANNER
CRYPTER MASTERS HACKERS EDITION
Crypter Matabarras
Crypter Medal Of Honor
Crypter Metal_Kingdom
CRYPTER MIERDA
CRYPTER MIND TRANCE
Crypter MISA DEATHNOTE
Crypter Mod Bob.Exe
Crypter Monster Blue
Crypter Multi Tool
Crypter Multiopcion
Crypter Music
Crypter Naxi
Crypter Need For Speed
CRYPTER NIRVANA
Crypter Nj Hacking
Crypter Nod32
CRYPTER ON AND OFF
Crypter Oveja
CRYPTER Party On Your Pussy
CRYPTER PEGASUS
Crypter PetaCabras!
CRYPTER PHOENIX
Crypter Porno
Crypter PRO
CRYPTER PROTECTOR
Crypter Protector
Crypter PSk
Crypter Rat
Crypter Rayssa Fernandes
Crypter Relax
Crypter Resident Evil
Crypter S-M
Crypter Sencill
Crypter Simple
Crypter Simples
Crypter Sin Nombre
Crypter Skyweb
Crypter SlipKnoT
Crypter Sophia Christina
Crypter Sr.1
Crypter Start-_-Game
CRYPTER TAME IMPALA
CRYPTER TEST
CRYPTER TIFONS
Crypter Tool
Crypter Tool's Basic
Crypter Underc0de
Crypter Veranito
Crypter Vibora
CRYPTER VICTOR
Crypter Vocaloid
Crypter VP publico
Crypter Wal999
CRYPTER WAR
CRYPTER WAR II
CRYPTER WESTERN
Crypter WinSeven 7
Crypter XP
CRYPTER ZEUS
Crypter Zombie Cementary
Crypter �3
Crypter �5
Crypter �6
Crypter �8
Crypter �9
Crypter �10
Crypter �11
Crypter �12
Crypter �13
Crypter �14
Crypter �15
Crypter �16
Crypter �17
Crypter �18
Crypter �19
Crypter �20
Crypter �21
Crypter �22
Crypter �23
Crypter �24
Crypter �25
Crypter �26
Crypter �27
Crypter �29
Crypter �30
Crypter �31
Crypter �32
Crypter �33
Crypter �34
Crypter �35
Crypter �36
Crypter �37
Crypter �38
Crypter �39
Crypter �40
Crypter �41
Crypter �42
Crypter �43
Crypter �44
Crypter �45
Crypter �46
Crypter �47
Crypter �48
Crypter �49
Crypter �50
Crypter �51
Crypter �52
Crypter �53
Crypter �54
Crypter �55
Crypter �56
Crypter �57
Crypter �58
Crypter �59
Crypter �60
Crypter �61
Crypter �62
Crypter �63
Crypter �64
Crypter �65
Crypter �66
Crypter �67
Crypter �68
Crypter �69
Crypter �70
Crypter �71
Crypter �72
Crypter �73
Crypter �74
Crypter �75
Crypter �76
Crypter �77
Crypter �78
Crypter �79
Crypter �80
Crypter �81
Crypter �82
Crypter �83
Crypter �84
Crypter �85
Crypter �86
Crypter �87
Crypter �89
Crypter �90
Crypter �91
Crypter �92
Crypter �93
Crypter �94
Crypter �95
Crypter �96
Crypter �97
Crypter �98
Crypter �99
Crypter �100
Crypter �101
Crypter �102
Crypter: GRACIAS SUDO
Crypter-BY_SLOW
Crypter-M-H_BY_SLOW
CRYPTER-DARTH
Crypter-Mafioso
Crypter-slowet
crypter...
CRYPTER....
Crypter_BY_SLOW
Crypter_by_slowet
CRYPTER_BY_SUDO
Crypter_Game_Over
Crypter_slowet
Crypter_slowet_SB
CRYPTER_SLOWET
CrypterbySB
CrypteRCN
CrypterXP_BY_SLOW
Cryptex
CryptExe
Cryptic
Crypting For Dummies
Cryptit
CryptItNow!
Cryptix Binder
CrypToCrack Pe Protector
CryptoFilez
Cryptographic File
Crypton!
Cryptonite
Cryptor SaudiHaCk
Cryptorious Crypter
Cryptosuite Crypter
Cryptosy
CRyptOZ
CryptWOZ
CryptX
Crypt[A3arTh]
Crypt[KZ]
CrypWrap
CrypXer
Crysis Crypter
Crystal Crypter
CS Crypter
CSDSJKK Protector
CuBe Crypt0r
Cucko Crypter
CuCo Crypter
Culazo Crypter
Culito Crypter
Cumpleanos Crypter 2013
Curinga Protector
Custom Unique Crypter
Cute j0!ner
Cyber Kryptor
Cyber-Sec Crypter
CyberCrypt
Cyborg Crypter
Cyborg Ninja Crypter
Cyborg Protector
CyberGate Crypter
Cybergate Crypter
CyberGate Undetector
Cybernetic Zombie Crypter
Cyborg Protector
Cypher Crypter
CyRuX CrypteR
Cyrux Crypter
D&C++ Crypter
d0pe crypter
D1S1G
Da Soul Spore Crypter
Da Vinci Simple Crypter
Dach - c[0]de Crypter
Daemon Crypt
DAEMON Protect
Dai-Crypters
DalKrypt
Dame La Vuelta Crypter
DanGer!CryptoR
Darck Angel Crypt3r
Dark Angel
Dark Angel Crypter
Dark Crypt
DARK CRYPTER
Dark Ghotic Crypter
Dark Souls Crypter
Dark-Angel Crypter
Dark_Warrior Crypter
DarkAngel Crypter
DarkAvengard
DarkComet Crypter
DarkMatrix Crypter
Darkness Crypt
Darkness Crypter
DarkNess_CRYPT
DarKoJa Crypter
Darkwar Crypter
Darth Daver Fail Crypt3r
David Guetta Crypter
Dayan Crypter
DB crypter
DBPE
DCrypt
DDeM
De la Buena Hoja Crypter
DE LA NADA A LA GLORIA
Dead Crypt
Dead Girl
Deagle Crypter
DEATH CRYPTER
Death crypter
Deception
Deck Crypter
DEF
Degra Crypter
Dehombreadios Crypter
DEJA vU CRYPT
Dekoders.net Crypter
DEKORDES CRYPTER
DelphBinder
demEnergy
Democres Crypter
Demon Binder
DEMON GIRL CRYPTER
Demon GX Crypter
Demonio Crypter
demXCryptor
dePack
Deregreso Crypter
Desayuno crypter
Desert Scorpion Binder
Desmoke Crypter
DevFrost++
devil and lady
DexCrypt
DezGhost
DF Team Crypter
DH Cripter
Di Maria Crypt
Diablo Crypter
Diablo III Crypter
Diamond Binder
DIET
DiGi-Binder
Digital Nemesis' Crypter
Dimon-z binder
Dimon-z Joiner
DirTy Cryptor
Disney On Ice crypter
Dive CryptOR
DJ Crypter
Djoiner
DK Binder
dl binder
DM Crypter
DNCrypter
DnKA Cryptor
DNSX Joiner
Doctor Crypter
Dog Crypter
Dolares Crypter
DollyDolly
Don't Stop The Party Crypter
Donfelipe
Doom Crypter
DOS Crypter
dotFakeSigner
Down Crypt3r
dpe
DPM CrYPT3r
Dr.House Crypter
Dr.True Crypt
Dr_Crypter
Dragao crypter
Dragon_Slayer
DRAGON AGE
Dragon Anime Crypter
Dragon Autoit Crypter
DRAGON BALL CRYPTER
Dragon Crypter
Dragon Crypter_
DRAGON PROTECTOR
DragonArmour
DragProtector
Dran And Drop
dret
dretblut Binder
Drony Application Protect
Droopy Binder
DSC - Crypter
DsCrypTer
DSJoiner
DTCrypt
Dual�s eXe
DuB7 CrypTer
DubsteP
Duff Crypter
DuneD Crypter
DuNeD@i CrYpTeR
DW-Crypt0r
DWN Sbratta
DxPack
Dz-Crypter
earth7 Free Crypter
Easy
Easy Packer NVC
Easy Binder
EasyBind
EasyCryptor
EazyE
EazyE Crypter
eblocrypt
Ecko Crypter
eCrypt0r
Ecu-Sec Crypter
EES Binder
Efecto Optico Cripter
Egy Crypter
Ejemplo Binder
El Bananero Crypter
El Bruto Crypter
El Flaco Skay Crypter
El Kuki Crypter
El Mono Mario Crypter
El Negro Crypter
El Padrino
El Puto Avira Crypter
El Trieto
ELBARTOkpc
ElecKey
Elite Packer
Elite Protector
eLiTe--TeAm CrYpTeR
Em0 CryPtEr
EmbedPE
Encriptador Indetectable
EnCryptPE
Encuentra a Wally Crypter
End Of Daze
Energy Crypt
Enfermera sexy
Enginar Crypter
Enigma
ENIGMA Crypter
Enigma Crypter
Enigmas Crypter
Enigmas Protector
EO Crypter
EP Protector
Epeius Crypter
Eres ese virus
Erviti Vuelve
eS304
Escargot
ESCLAVOS DEL SISTEMA CRYPTER
Eset Nice Crypter
Espace Crypter
Espana Crypter
espatarramonjas crypter
Essential Crypter
Estafador Crypter
Estoy De Vuelta
Estrella Crypter
Estupido Unicornio
Eterno Campeon
Eurocopa 2012 Crypter
Evil Crypter
Evil Dragon Crypter
EvilBinary
EvilCrypter
EvoLution bInder
Ex Binder
EX-Crypt Light
Excalibur
ExChain
ExCrypter
EXE,JPG File Binder
Exe-Binder
exe-joiner
EXE Binder
ExE Evil
Exe Guarder
Exe in Exe joiner
EXE Lock
EXE Obfuscator
EXE Pack
EXE Password
EXE Protect
EXE Protector
Exe Stealth Packer
Exe Stealth Protector
Exe Wrapper
Exe32Pack
ExeBundle
EXECrypt
ExeCryptor
ExeDefender
ExeFog
ExeGriper
EXEJoiner
ExeJoinerTM
EXERefactor
EXESafeGuard
ExeSax
ExeShield
EXESmasher
Exorcista Crypter
Experimental
Experimental Crypter
EXPLICIT CRYPTER
eXPressor
ExProtect
Exterminador Crypter
Exterminator Crypt3r
eXtra Bind
Extra Element Crypter
Extra Private
Eye Crypt
Eye Crypter
Eye's God Crypter
eYe's Stealth Unit
Ezio crypter
EZIP
F.B.I
f@rk Crypter
Face da Morte
Facebook Crypter
FailCrypt
FakeNinja
Fakus Cryptor
Falckon Encrypter
Fallen Crypter
Fantasy Crypter
farbrauschPE
Fast File Crypt
FastPack
Fatalz Crypt
FatMike
FBI Binder
FBinder
FC Crypter
Fearless Bind
fEaRz Crypter
fEaRz Packer
Felicidades *Isabella* Crypter
FELIZ 2014
Feliz Ano
Feliz Ano 2012 Crypter
FELIZ ANO NOVO
Feliz Ano Novo 2014
Feliz Navidad Crypter
Fender StratoCrypter
Fenix Binder
Fenix Crypter
Fenix Dark Crypter
Feokt
Ferrari Black Protector
Ferrari Crypter
FETiOP
fEvicol
fexx crypter
FFC
FIFA 2010
Fifa World Cup Brasil 2014
FIGHT CRYPTER M3
Fighter Crypter
File Crypter
FileBind
Filebinder
FileJoiner
FilePacker
FileShield
FingerLight Crypter
Fire Crypter
Fire Hands Love Crypter
Fire Joiner
Fire Skull Crypter
FireFox Crypter
FishPE
Fjuxs Binder
Flame Packer
Flash Crypter
Flashback Protector
fligth 666 Crypter
Fly-Crypter
Force Crypt3r
Forest Crypter
Form1
Form1 Simple
Form1+2+3+4..._CRYPTER
Form30
ForMalBinder
ForoMalware
ForoMalware Binder
FoRRa CryPter
FortiClient Crypter
Fortune City Crypter
FORUNS crypt
FProt
Frame Crypt
Fran Regresa
Franbv2009 & Leem Crypter
Franbv2010 Crypther
Francis Cryptor
Frankenstein
Freddy Kruguer Crypter
FREE Crypter
Free Joiner Small
FreeCryptor
FreeJoiner
Freex64
FrenchLayor
Freshbind
FriCryptor
Frusion
Fruteria
FSG
FuCK AV Cryptor
FUCK AVIRA Simple Crypter
Fuck It All
Fuck Lammers Crypter
Fuck Matematicas
FUCK YOU
Fuck You Crypter
FuCk! System Crypter
Fucking NOD32 Crypt3r
Fucking Poli-A Crypter
Fucking Polimorfic Worm Crypter
FuckIsrail Binder
FUD Crypter
Fud Machine
FUD ME Crypt0r
FudsOnly.com.ar Crypter
FuKrypt
FULANA CRYPTER
Full Research Crypter
fUrIoUs Crypter
Fusion Auras crypter
Futurama Crypter
Fuzz Buzz Crypter
G!X Protector
G-CrYpT
G-UNIT
G3 crypter
Gaara Crypter
Galoucura Crypt
Game Card Crypter
Games Crypta
GameShield
Gangsta TubbieS
GANTZ Crypter
Gargula
Gatinho Crypter
Gato Balboa Crypter
Gato Preto Crypter
GavnoCrypter
Gbind
GearCrypter
Gears Of War Crypter
GeCko-Crypt
Geek Crypter
Geisha Priv8 Crypter
gemma Crypter
Gentlemen Crypter
Gezeta TopSecret
GhaZza CryPter
GHF Protector
Ghost Rider Crypter
Ghost Rider Protector
Gie Protector
GiGa Binder
GiGa Crypter
Gio Crypter
Gio Packer
Gipson Polycrypt
Girl Copy
Girl Exorcist
Girl Green
Girl Rogue Crypter
GKripto
Gladiator Crypt
Gleam
Glock
GOAL Crypter
Goats PE Mutilator
God Of War Crypter
Godric
GodWall's Blinder
Goku Crypter
Gold Crypter
Google Crypter
Google crypter
Google CryptR
Gorillaz Protector
Gostosa crypter
Gothic_Crypter
Govnocrypt
Gracioso Crypter
Grand Theft Auto 5
Graveworm Binder
Green dreams_crypter
Green_Crypt
GreenGap
Grieve Crypter
GringoCrypt
GSCryptor
GSJoiner
Guardian Protector
Guitarra Crypter
H.N.F Binder
H4ck-y0u.org Crypter
H4Ck|NG CRYPT3R
H7 Labz crypter
H7 Labz B1nd3r
Ha Ha! Crypter
HAC Crew-Crypter
Hackbase.cc Crypter
Hacker Okan Crypter
HackHound Mass Binder
Hacking.gvu.cc Crypter
Hack_Or_Die Crypter
HackSecu Packer
Haggen-Dazs Macadamia Nut Brittle crypter
Hello Kitty Crypter
Halloween Crypter
Halloween Packer
HaLV Crypter
Hammer Binder
Hanjian Packer
Hanneman Crypter
Hannibal Crypter
Hao Asakura Crypter
HAO Crypter
Hao Crypter
Happy Birthday Crypter
Happy day bro_cryp
Hard Crypter
HarD-Style Crypterz
HardCore Soft BindeR
Hardened Crypter
HarDStyle Binderz
HARLEY-DAVIDSON
Harmmy Crypter
HaspSRM
Hat Crypter
HateMe Cripter
Hatrex Cripter
HayiR Crypter
HD85512b Crypter
HEIDI PORRERA-BINDER
Heineken Crypter
HelioS-Binder
Hell Packer
Hello Kitty Crypter
Helminth Crypter
HH Binder
HH Crypter
HH-Crypter
HiDDeN SaBoTaGe Exe Binder
Hide Protect
HidePE
HidePX
Hierba Crypter
HipACryp
Hiper_Crypter
HipHop Crypter
Hipnosis Crypter
Hmimys Packer
HolyTuRK
Homaneje Crypter
Hombre Crypter
Home Simpsons
HOMER CRYPT
HoMeRo CrYpYeR
Horrible Crypter
Horus Crypter
Hound Hack Crypter
HSN.C3r protector
HTID Crypter
HUcrypter
Huipter
Hulk Crypter
HULK Destructor
Hulk Krypt
Humans & Aliens
Hunger Games Crypter
HUNT3R CRYPT3R
Hyings PE-Armour
I Dont Know The Name Crypter
I Hate Doctors Crypter
I like It! Crypter
i-hacker.info Crypter
Ibackgroundz Crypter
iBinder
Ice Binder
ICE License
IcebergLock
IcePoint Botnet Binder
iChipher
ICrypt
ID Application Protector
iEncrypt
IExpress
IFUD Crypter
Ignaro Crypter
Ignaro Mayor Crypter
Ignaro Mayor de BsAs EXE Binder
IKARUS Security
Ilusion crypter
Ilusionismo_Crypter
Image Crypter
IMP-Packer
IMPacker
in To The Wild Crypter
Inbinder
Incrypter
Ind-Binder
Indetectables B1ND3R
Indetectables Binder
Indetectables Crypter
Indetectables Cryptor
Indetectables FUD
Indetectables Krypt3r
Indetectables Protector
Indetectables Simple Bind0r
Indetectables Tribute Binder
Indetectables X Crypter
IndetectablesLock
Indio Solari Cripter
IndSocket Crypt0r
iNF Cryptor
INF'[JOINER]
InFam0us Binder
Infected Pig Crypter
Inferno's Crypter
InfiniTe Binder
Infinite Crypter
Infinity Crypter
InfinityJoiner
Ink Crypt
Inspiration Crypter
Interlaced
INTERNACIONAL CRYPTER
Intruder Rules
INV4S10N Binder
Invisus
Invited Whom
Invius
Inyeccion china Crypter
Ipacker
iPBProtect
IProtect
Iraqi Crypter
IRINA SHAYK
Iron_Crypt
Iron Crypter
Iron Maiden Crypter
Iron Man
Italia Crypter
ItzTheHell Crypter
Izel Crypter
J Multi Binder
J-BiNdEr
J.LO Crypter
J0k3r
J8994's Basic Cryptor
J@H CrypteR
Ja ja Crypter
Jack Daniel'S
Jah Rastafari Crypt0r
JAJA Crypter
Jamaica Crypter
Jamaica No Problem Crypter
James's Crypter
Japabrz Cryptor
Jaque Khury Crypter
JasaHackBindeR
Jasakom Crypt
JCrypt
jCrypter
JDPack
JDProtect
JERINGA CRYPTER
Jessita Binder/Crypter
JExeCompressor
JeyJey UPX Protector
jFriend Crypter
Jhou_026 Crypter
Jin & Jan Crypter
JKymmel's Crypter
Jocker Crypter
JoDeDoR Crypter
Jodete sn0x Crypter
Joe Satrian Crypter
joels Cryptor
Join It Now!
Joiner asd
Joiner By Spide
Joiner by Vayrus
Joiner Liberado
JoinerCHK
JoinR
Joker Protector
Jonathan_Crypter
Juego Crypter
JUJU Panicat
Juliana Salimeni Crypter
Just Another PE Packer
K!Cryptor
K1NK1 Crypter
k7 Simple Crypter
K.O Crypter
KAERKRYPTER
KaKa Crypter
Kakashi Crypter
Kami_Nagato
Kanat Crypter
KaOs PE-DLL eXecutable Undetecter
Karcrack Joiner
Kaser-Crypter
Kaspersky Crypter
Kaspersky crypter
KasperSky Pack
KATY PARRY CRYPTER
Kaway_Ameri
KByS
Kebab Crypter
KenPack
Keton
Key Crypter
KGB Crypter
KGCrypt
KiAmS Cryptor
KiD Crypt
KILL ZONE
KillZone Crypter
KiM Kardashian Crypt3r
KiRoV Crypter
Kiss
Kkrunchy
Kleopatra Protector
Kner Binder
KNOCKOUT CRYPTER
KobacCrypter
Kokox Crypter
Komputilo's Crypter
KRATOS CRYPTER
Kratos Crypter
Krypter $oraya Carioca
Krypter Arianny Celeste
Kriptirnik
Krypto Crypter
Kriptors
Krishee Crypter
Krypt Xtreme Rat
Krypton
kryptor
Kryptos
KsA Bind3r
KUCUK EMRAH
Kur0k.X2.to
Kurt Cobain Crypter
Kurtix Crypter
Kyahack Designer
Kyubi Crypter
Kyzer23 Crypter
L-Pack
l0lCryp3?
L1ght-Crypt3r
L1MIT Crypter
L1v3H Crypter
L33T CRYPTER
L3vel Crypter
La Casa Bonita
La Doncella De La Muerte
La Formula Crypter
La Glorius Romanus Crypter
La Haine Crypter
La Pequena Diabla Protector
LA POLLA RECORDS CRYPTER
La Profe Crypter
La Rubia Crypter
La Seleccion Crypter
Lab's Crypter
LAMBORGHINI TRON
LamBorguini Protector
LameCrypt
Lanu5hhh Pinguino
Larissa Riquelme
lARP
LC Crypto
Leaf's Crypter
League Of Justice Zombie
LechuGa CryptR
Leem Crypter
LeetCryptor
LEGAL CRYPT
Legal Joiner
LEGAL WOMAN COOL CRYPT
LeM Crypter
LEO
Leon Crypter
LeonDk Crypter
Lesbian Crypter
Lesbian Protect
LET'S KILL AVS CRYPTER
Level 23 Crypter
LeVeL-23
Level-23 ChristmaS
Level-23 Crypter
Level-23.net Crypter
Level23
Lexies Crypter
License Protector
Light Blue Crypter
Light Crypter
Lightning Crypter
Lightning Joiner
LIGHTS Crypter
Lighty Compressor
Lilith
Lilith Crypter
Lineage Crypter
Linkin Binder
Lion Joiner
lionel Messi Crypter
LIPacker
LiQuid Vapour
Lite Binder
Lithius Crypter
Lito Vitale Crypter
Live Free Or Die
lizzy Crypter
Lo mejor de la musica
Lobo Siberiano Crypter
LockDown Crypter
Log&Joiner
LOL Crypter
LOLIPOP SIMPLE CRYPTOR
Lora Crypter
LOrD-Crypter
Los Aldeanos Crypter
Los Simpson Crypter
Los timadores
Lounger Crypter
LoVer hEx Crypter
Loys Crypter
LTA Avira
LTC
luchoPR
Luciana Salazar Crypter
Lucif3R CRYPT3R
Luck007
Lucky Strike Crypter
LuCypher
Luisma Crypter!
LuisN2 Crypter
Lula Crypter
LulzCrypter
Luna Crypt
Lunar Cript
LuOpP Crypter
LUXURY CRYPTE
Lyoto "San" Machida Crypter
M-Security Crypter
M0nst3rVip
M3 Crypter and Joiner
M3 Image Crypter
M3 PROTECTOR
m3m0's Crypter
M3N3 Crypter
M4A1-Custom
M_W_BLACK_CRYPT
M_W_CRYPT
Mac 2 Crypter
Mad Clown Crypter
Madara Crypter
MadnessCrypter
MADRID-BARCELONA
Magic Binder
Mago Erviti Crypter
Maiden Christmas Crypter
Mal Packer
Mal_CRYPT
Mala Semilla Binder
Maldito crypter
Maldito Flanders Crypt
MalWare ReMakeR
Malws-Zone Simple Crypt
MALWS-ZONE.NET BINDER
Mammoth Protector
Manga Crypter
MANHUA Crypter
Manolo
manssion Crypter
MarCrypt
Marea Crypter
Maria Crypter
Marihuana Crypter
Marjinz Crypter
Masa Crypter
Mask Crypter
MaskPE
MassBinder
Mast3r-Crypt3r
MASTER-HACKERS CRYPTER
Master Binder
Master Of Universe Crypter
MASTERS HACKERS
Matabarras Crazy
Matatan Crypter
Matrix Crypter
MatrixCrypt
Maxi Crypter
MAYRA CARDI CRYPTER
MBinder
Mc Crypter
McPhiros Guard Protector
MCrypter
MCYP
mdCrypter
Me gusta
ME RIO EN TU CARA CRYPTER
Medusa
MegaCrypt
MEGADEATH Crypter
MegaDeth Crypter 
Megaupload Crypter
Meme Crypt3r
Men in Black
Menage Binder
MeNDIL Binder & Crypter
MERLIN CRYPTER
Metacrypt
Metal Crypter
Metal Girl Crypter
Metal_Crypt
METALIC CRYPTER
Metallica Crypter
Metric Crypter
MEW
MEWCRAP
Mexico Crypter
MI DIOSA XD
Mi Ex Crypter
Mi Primer Crypter
Michael Jackson Binder
Michael Jackson Crypter
MicroJoiner
Mikemmel! Crypt
Milan Crypt
Miles Mortem Crypter
Military Crypter
Mimoza
Mingo Crypter
Minguito Crypter
Mini Aquiles Crypter
Mini Crypt
MiNi CrypteR
Mini Crypter
Mini crypter
Mini FUD
MINI-NINJA
mini-undetector
MiniMultindetect
MINION
Minions Crypter!
Minke
Mitsubishi Eclipse GT Protector
MKFPack
Mocosoft crypter
Mod Crypter
Modbob Crypter
ModdedFog
Moderadores Rositas Crypter
Modern Warfare Crypter
Mogolux Crypter
MOH Crypter
MOJITO
Mole Spy
MoleBox
Money Crypter
Monkey Joiner
Mono Crypter
Monster_CRYPT
Monstruo de las Galletas Crypter
Monumento a la Bandera
Morena
Morena Crypter
Morph�rypt
Morphine
Morphnah
Mortal Crypter
Mortal Kombat Crypt0r
Mortal Team Crypter
MoruK creW Crypter Private
Most Security
mOST sECURITY Crypter
Most-Security Advanced Crypter
Most-Security Crypter
Most_Crypter
Mota Crypter
Motoqueiro fantasma CRYPT
Mourinho VS Vilanova Crypter
mPack
MPress
Mr Undetectable
Mr. Alien Crypter
Mr. FUDMan Crypter
MSLRH
Mu$hRo0M CryPt0R
Mucki's Protector
Mueran Avs Crypter
MUJER TOP SEXY
Multi Binder
Multi Crypter Elite Banker
Multi File Binder/Crypter/Joiner
Multi Files Binder
Multi Files Joiner
Multi Packer
Multi Pink Joiner
MultiCrypt
MultiCrypter
MultiMiniCrypter
Mumia Crypter
Mundial Crypter
Municipal Waste Crypter
MuRKRoWs Crypter
MUSIC V1
MUSIC_CRYPT
Music_crypter
Musik
Mustang GT Crypter
MW3 Crypter
My PE Packer
MY PRECIOUS_cr3pt3r
MyCrypt
Mysterious Crypter
Mystic Compressor
MZ-Crypt
MZ0oPE
N-Code
N-Joy
n4rc0hack3r Crypter
NakedBind
NakedPacker
Nalguitas Ricas Crypt3r
Nameless Crypt
NaoSei
NarcisCryptador
Naruto Crypter
Naruto VS Sasuke Crypt3r
Nathan Binder
Navidad Crypter
Nayer Crypter
nBinder
Ncorw81 Packer
NCPH
nCrypt
Near
Nebulosa Cripter
NeeD Cumple Crypter
NeeDemo Crypter
Nelson Crypter
Neme Binder
Nemesys Crypter
Nemesis Protector
Nengo Flow Crypter
Nenita Cripter
Neo Binder
Neo Da Cryptor
NeoLite
NeoWare Crypter
Nephron Binder
NetCrypt
NetWalker
Never Changer Crypter
NEW CRYPT
NewHacks Crypter
NEX Binder
Neymar Crypter
NFO
NG Binder
NiceProtect
NICOLE BALHS CRYPTER
Nidhogg
Night Crypter
Night Sky Crypter
NIGTHMARE CRYPTER
Nightshade
NightWolf Binder
Nikki Griffin Crypter
Niller Crypter
Ninfa Crypter
NiNGiSHZIDA
NiNj4 CrypteR
Ninja Assassins Crypter
Ninja Crypter
nInJa CrYptOr
Ninja Private Crypter
Ninja Protector
Ninja Sexy Woman Crypter
Nirvana Crypter
Nitro Crypter
NITRO K- CRYPTER
NJRAT Crypter
njRAT CRYPTER
njRat Crypter
NME
NNS Crypt
No Estaba Muerto Estaba De Parranda Crypter
No Name
No se como me llamo crypter
No Tengo GuI
No To Racism Crypter
No_WaR Crypter
NocheVieja Crypter
Nocturnal Crypter
NOD32.Matabarras
NOmeR1
NoNamePacker
NoodleCrypt
Nork Joiner
NoteCrypt
NovaCipher
NOVATO CRYPTER
Noveno Crypter
Novinha Crypter
noX Crypt
Noxious Binder
nPack
NsAnti
NsPack
NsPack Scrambler
NT Crypter
NTkrnl Packer
NTkrnl Protector
NtPacker
Nuevo crypter
Nuevos Rangos Crypter
Nuotatori Professionisti Crypter
NW Binder
NX PE Packer
Nyan Cat Crypter
Oasis Crypter
Obamas Binder
oBinder
Obsidium
Octopus
Octrix Crypter
Odessa Crypter
OG-HiDER Crypter
Oh No Mataron A Kenny!
OhShin Crypter
Ohuom Ben Ya
Ojete Lesbico Crypter
Old Dirty Bastard Crypter
Olivia Booty Crypter
Olivia Cryptr
Olmedo Y Porcel Crypter
On The Fly Crypter
Online Binder
Op3nSrc CrYpt3r
Open Source Code Crypter
Optiikzz Crypt
Optik Russia Crypter
Orange Crypter
Orange Libre
Orbz Crypter
OrCrypt
Oricalco
Orien
Original_cryp
OS Protector
OSC-Crypter
OTRA MOVIDA
Otro Crypter Sin
Otro Simple
Otro Simple Crypter
Ottoman Crypter
Outl4ws~Crypt3r
Overdoz
Own'Z Crypter
P.Q.P.I Joiner
P0is0n Protector
p0is0nJoin
p0is0nsit0 Crypter
p0ke Crypter
p0ke scrambler
Pac-Man Cript
Pacbind Binder
Pacific Rim Crypter
Pack
Pack Master
PackItBitch
Packman
PackNot Crypter
Padre de familia
Pain Crew Protector
Palhaco Protector
Pandora Crypter
Pantera Crypter
Panthon Crypter
Papa Noel Borracho Crypt
ParaFAL 7.62
Parameter Crypter
ParaProtect
Paris Crypter
parL0us Crypter
Password Protect UPX
Patricia Conde Crypter
Patricio Rey Y Sus Redonditos De Ricota
PAV.Cryptor
Payaso Crypter
PC PE Encryptor
PC Shrinker
PC-Guard
PCShrink
PE Crypt32
PE NINJA
PE Pack
PE Samourai
PE Shrinker
PE-Armour
PE-Hide
PE-Patcher+Cryptor
Pe123
PE32
Peacefull Crypt
PEBind
PeBundle
PeCancer
Pechotes Cripter
Pechuga Crypter
PeCompact
Pecorina Crypter
PEcrypt
PEDiminisher
Pedrito90 Crypter
Pedroche Crypter
PEEncrypt
PeGaSus Crypt3R
Pelado Crypter
PELock
PELockNT
PEMangle
PEncrypt
PEnguinCrypt
PENightMare
PEProtect
Pepsi
PEQuake
Percutible Crypter
Perfect_Hackers
Perplex PE-Protector
Perritas Argentas
Personal Crypter
Peruana Crypter
PESHiELD
PEShit
PeSpin
Pestil
PeStubOEP
Petite
PewPew Crypter
PeX
PEZip
PFE CX
PFIGFO BINDER
Phantom
PI Cryptor
Picture's Binder
Pielcelestial Crypt3r
Pikachu Moustache Crypter
Pimp Crypter
PinBall Crypter
Pinguino Binder
Pink Gingerbread Crypter
Pirata Crypter
Pistolero Crypter
PITBULL CRYPTER
Pitbull Crypter
PITBULL SECURITY LAB'S PROTECTOR
PKLite32
Plague Binder
Planet Crypter
Plaza Crypter
Plex
PlutoCrypt
PMSJoiner
Pocker Protector
Pohernah
PointBad Crypter
Poisen Ivy Crypter
Poison Crypter
Poison Ivy
Poison Ivy Crypter
poket crypther
Polifemo Crypter
Polifemo Ebrio Crypter
POLIMORPHIC CRYPTER M3
Polito Crypter
Pollon Crypter
POLVOS LOS JUSTOS
Poly!Crypt
PolyBox
PolyCrypt PE
PolyEnE
PolyMorPhic Xor Crypter
Porco Rex
Porno Crypter
Power Crypt
Pregunta de el millon de dolares Crypter
Premium Crypter
Present Packer
Pretator
Pribate
Prince Of Persia Crypter
privada_Dragon
Private Crypter Dark Souls
Private Crypter MataBarras
Private Crypter Spray
Private Exe Protector
Private Fud
Private Personal Packer
PrivateKrypt
PrivatePatcher
privet crypter
prjCone
ProActivate
Process Crypter
Process Joiner
ProcessKill Crypter
ProCrypter
Program Protector
Prologue Crypter
Prosolution Crypt
Protect CryPT
Protect Kaway
Protect Shareware
ProtectDisk
Protection Plus
Protector Aline
Protector Avira
Protector Blanka
Protector Brasil
Protector By Kaway
Protector Cris Andrad
Protector CyberGate
Protector Nod32
Protector Simple
Protector Xtreme Rat
Prox Crypter
Proyecto Crypter
PS Crypter
pScrambler
Psicos Crypter
Psycho Binder
PTER
Pub Crypter
Public Crypter
PUNiSHER
Punk crypter
PureBiND3R
PureCrYpT3R
Puri Crypt
PussyCrypter
PUTO CRYPTER
puto panda
Puttana
Puuuum Crypter
Pwned Crypt
PXCrypter
Q Crypt
QrYPt0r
Quarantined Crypter
que paso ayer
Que Te Jodan Crypter
Que ven mis ojos Crypter
QuickPack
QwEErz BiNdEr
R-007 CRYPTER
R-S Crypter
Racing
Racionais MC'S
RadaR True Crypter
RaDiC Crypt3r
Radical Crypter
RADIOHEAD Crypter
Raditz
RAFA NADAL vs ARGENTINA i TODO SU
RaidenX Crypter
RainBow In The Dark
Rainerstoff
Rakabulle Binder
RAMMSTEIN CRYPTER
Rap Crypter
Rapid Binder
Rasmuz Crypter
RAT Packer
RazorCrypt
Rc4 Cryptor
RCryptor
RDG Pack
RDG Tejon Crypter
RealCrypt
RealMadrid Crypter
RealMadrid Vs Ajax
Reaper Crypter
Recio Crypter
ReCrypt
Red Dev1L Crypter
Red Dragon Crypter
Red Monster
RedbindeR
RedBlackEdition
Redes Crypter
ReDiX Crypter
redlight_crypt
Reductor
Refruncy Crypter
REI DA RUA CRYPTER
Reinke's Crypter
RekCryter
Reload Crypter
Relva Crypter
ReMod! Crypter
Rephlex Binder
Represent Of Indetectables
RESCrypt
ResCrypt
Resident Evil Crypter
Revelion Joiner
Reversi Crypter
ReversingLabsPack
ReversingLabsProtector
Revolu-Encriptor
RevoluPimp
Reyes Magos Protector
RianTR Proctector
Ricota Simple Crypter
Right Crypter
RING GIRLS CRYPTER
Rio 2016 Crypter
RIO ENFERMERA SEXY CRYPTER
Ripped Crypter
RJoiner
RKT's Crypter
RobinRecord Crypter
Robot Crypter
Roccat Crypter
Rock Crypter
RockCrypter
Rockito crypter
Rocko Crypter
Roda Crypt
RodaCrypt
Rodanet
RogueCrypt
RoguePack
ROOTSYSTEM CRYPTER
Rose Cryptor
Royal Crypter
Royce Gracie Crypter
Royden crypter
RPolyCrypt
Rub3
Rubbish
Rubiaca Crypter
rubiaza crypter
rude surprise binder
Rudeboy crypter
Ruleta Rusa Crypter
RunCrypt!
Rune Crypt
RunPE Killer
Russian Cryptor
RW Crypter
S!mpl3 CrYpT
S-A-H
s0ftcorn Crypter
sabota
Sad Old Man
Saddam crypter
Safety Last Group Protector
Sanin Crypter
Sanlegas Crypter
SantaFe Crypter
Sasha Grey Crypter
Sasuke Crypter
Satan's Crypter
Satelite Crypter
Satyricon Crypter
Saudi CrYptOr
Saw Crypter
SBinder
SC Obfuscator
Scancryptic Joiner
Scantime Crypt0r
SCB Lab's Crypt0r
SCB Lab's Joiner
SCD [binder]
SceneCrypt
Sch...
Schattenreich Crypter
School hack CrYpTeR
Schwarze Sonne
Scofield's Cryptor
Scorpion Crypter
Scorpions MotherFucker Crypter
SCPack
Scramble Tool
Scream Crypter
SCrypt
SCrypter
Scrypter
SD Crypter
SDProtector
se busca perro
SecuPack
Secure Crypt
Secure Crypter
Secure Shade
SECURE TEAM CRYP'TER
SecurePE
SecureWorld Binder
Security Essential CrypteR
Selassi Binder
Seleccion espanola
Self Decrypting Binary Generator
Sell Crypter
Sello Asesino
Sem palavras...
SendSpace Crypter
Sensual Blonde Crypter
Sensual Crypter
SEPTIEMBRE ES NEGRO CRYPTER
Sepultura Crypter
Seritx's Binder
Seritx's Crypter
Sexe Crypter
Sexo Seguro Crypt
SEXY
Sexy Binder
Sexy BindUrl
Sexy black crypt
SEXY CRYP
SEXY CRYPTER
SexY cRypter
Sexy Crypter
Sexy Girl Crypter
Sexy Guitar Crypt!
Sexy Ninja Crypter
Sexy Private Crypt
Sexy Protector
Sexy' Catira Crypter
sexy-guitar_crypter
SEXY_CRYPT
Sexy_Crypt
SEXY_WHITE_CRYPT
SexyPacker
SFJoiner
Sh!T BindeR
Sh7bor Binder
ShadeCrypter
Shadeh4Ck Crypter
SHADeR
Shadow Crypter
Shadow Of The Colossus Crypter
Shakira Crypter
Shaman KingCrypter
Share Crypter
Shark Dead Crypt
SharKCrypter
Sharki Crypter
SHARKS
Sharp FUD Crypter
Shegerd Exe Protector
Shield Crypter
Shikamaru Crypther
Shimmi Crypter
ShimpRun Binder
Shitty Binder
Shlapo Joiner
SHNi Joiner
Sh00t Binder
Sh0ck Packer
SHNI Joiner
ShOcK CrYpTeR
ShockLabs File binder
Shotokan Binder
SHProtector
Shrinker
Shrinkwrap
Shyla Stylez Crypter
Sickrypter Mini
SIETE BRAVO CRYPTER
SigNY Small Crypte'R
Sikandar�s Crypter
SilkRopeBind
Silla Feliz Crypter
SiLLenTz Protector
Silly Chr Encrypter
Sim Crypter
SimbiOZ
Simple
Simple #2
Simple ANONIMOSX Crypter
Simple Binder
Simple Binder Ghost Rider
Simple Crypt
Simple Crypter
Simple crypter
simple DnKA Cryptor
Simple File Binder/Joiner
Simple Form1
Simple Level-23 Crypter
Simple Novo
Simple Pack
Simple Protector
Simple Prueba Crypter
Simple Strreverse Encryption
SiMpLe TuTo CrYpTeR
SimpleBinder
Simpleh Jumpstyle Binderz
Simplemente Simple Binder
simples...
Simples Binder
Simples Black crypter
Simples crypt
Simples Crypt
simples crypter
Simples crypter
Simples Crypter
Simples Free
SIMPLES JOINER ELITE
Simples_Crypt
Simples_crypter
Simpleza Crypter
Simplicity Crypter
Simpsons Rock
Sin Diseno Binder
Sin Miedo Crypter
Sin Nombre
SINCrypter
Sintatic Crypter
Sintetic Protector
Sixxpack
Sk1D Crypter
SkD Undetectabler
Skeleteon Commander Crypter
SkidTime Crypter
Skillmax Crypter
skorpien007 crypter
sKrIlLeX CrYptOr
Sku1L_cr3pt3r
Skull Crypter
Skull Green
Skull Protector
SkUlL_Cr3pt3r
Skull_CRYPT
Skull_Rose Crypter
SkuLLByte Crypt
SkullSea Protector
SKUUL
SKUUL CRYP
SKUUL CRYPT
sKuuL_CRYPT
Sky
Sky Crypt
Sky Protector
SkyFe
Skype Crypter
SKYSAN CrYpTeR
slackpack
Slave Binder
Slayer 616 Crypter
SLENDER MAN CRYPTER
slickpack
SlimDeath Binder
SlimDeath Crypter
slipknot
SlipkNot Crypter
Slipknot Crypter
Slipknot Protector
Sludge Crypter
SLVc0deProtector
Small Crypt3r
Small Crypter
Small File Binder
Small joiner
Small Polymorphic Crypter
SmokeScreen Crypter
SmokesCrypt
sNaKe CrYpTeR
Sniper Crypter
Snoop Crypt
So pentada violenta Simples Crypter
Sobrenatural Crypter
SoftProtect
softSENTRY
Software Compress
Sol Crypter
SOLEid
SOLiD Binder
SoLiDMoRPH Protector
Solitario Crypter
Solitario EL Kill De la Eucaristica
Solo En Venezuela Crypter
Sonsuzluk Crypter
Sopelka
Sophos Crypter
Soprano Crypter
Sora Crypt
Soul Eater Crypter
Source crypter
South Park Crypter
Sp1r1tus binder
Sp1r1tus joiner
Sp4|N--CryPt3R
Space Crypter
Spain World Cup Champions Crypter
Spanish Protector
SPEC
Special Crypter
Special EXE Pasword Protector
Spectrus Crypt0r
SPEED Crypt3R
SPEED CRYPTER LITTLE
SPEED PROTECTOR
SPICA CRYPTER
Spider Binder
SpideR BlacK
Spider Packer
Spirit's Packer
SPLayer
Spliknot
Splitter
Spread Crypt
Spy Crypter
Spy Eye Crypter
SpY NeT Rat Crypt0r
Spy-Crypter
SPYNAL CRYPTER
Spynet Crypter
SpyNet Priv8
Square Crypter
SqUeEzEr's Crypter
Sr. Crypter
Sr.Agent
ST Crypter
ST Protector
StarForce
Starry Night Over the Rhone
StArT-_-GaMe Crypter
StasFodidoCryptor
Ste@lth PE
StealTh TooL
Stewie Stalin Crypter
STL Packer
STL WebDownloader
Stone's PE-EXE Encrypter
Stonedinfect Crypter
Storm Cryptor
StrAnGe CrYpTeR
StRaXxXD File Binder
Strup Joiner
STUB
Stub Error Crypter
Stvrt Cryptor
Style'S Crypter
Sub Zero Crypter
submarine-rat.com crypter
Summer Crypter
SunS Joiner
Sup Crypter
Super ASS Crypter
Super Binder
SupEr CrAzY
Super Fast File Binder
Super glue for EXE
Super Sayajin Crypter
SuperCrypt
Superman Crypter
SupermanCrypt
SuperPacker
Surprise Crypt0r
SuSoO Crypter
SVK Protector
Sword_Swallower Crypter
SyCo Packer
Sylar crypter
SyMoH Crypter
SynBinder
SynhaxCrypt
SynPacker
SYSTEM_crypter
T's Crypter
t0r Bind
T0X1C Crypter
T@KEN Crypter
T.S.H PRIVATE CRYPTER
Taakj2005 Private
TableCrypt
Tages
TAI 42 Crypter
Tanque'Crypter
Tarex Crypter
Tasquil
Taurus Protector
TCP Crypter
Team Crypter
Techo Negro Crypter
Tefy Crypter
Te gusta Cogote
Teh Crypter
Tejon Crypter
tElock
TESUDA CRYPTER
TeToNa CrYpTeR
TetraPack
TGR Crypter
TGR Protector
Th3-0n3 Crypter
Tha BOO CrypterR!
ThC Crypter
The Art Of Deception
The AV Fucker Crypter
The Best Cryptor
The Big Bang Theory Crypter
the black kind simples crypt
The chikahackk- Simple Crypter
The Chronicles of Riddick
The Clown Crypter
The Cood's Crypter
The Crypter Zone
THE darck ANGEL
the darck crypt
THE DARCK KIID
The DarkSide Door
The DeaD B!nDer
The Death Crypt
The devil and angel crypt
THE DEVIL AND ANGEL_CRYPT
The Dragon Crypt
The Drinky Cripter
The element cryp
THE ELEMENT CRYP
The Encryptor Hacker
The Eyes
The Fuckin Oresme Binder
The Fucking Exam Crypter
The Gathering Binder
The Girl Crypter
The GodFather Crypt
The Jocker _Batman
the kid...
the kiss
THE LADY CRYPT
The Legend of Spyro
The Little Crypter
The Misfits Libre
THE miss DEVIL
the miss music cryp
The miss_cryp
The pixel's black cryter
The Prodigy Cripter
The Punisher Of AVs Crypter
THE ROSE CRYPT
THE STRIPPER CRYPTER & DOWNLOADER
The Troll Crypt
The Walking Dead
The WallKing DEAD Crypter
THE WOLF CRYPT
THE WOMAN CRYP
the Woman_CRYP
The Zeta Project
The Zone Crypter
TheCrypter
Themida
Themis Binder
ThePka - Crypter
Thiagao e os Kamikazes do Gueto
Thinstall
Thrash Attack Crypter
ThreatConceal
THUNDER CRYPTER
Thunderbolt
ThunderStorm Crypter
Tiburon Crypter
TIGER
Tiger Fud Crypter
tikkysoft joiner
Tiny crypter
TinyCrypt
TiposRaros Crypt
Tiroloko Crypter
Tish's Crypter
TiXor b!nder
TNT Crypter
To Hell And Back Protector
Toma1
toMcrypT
TONY DIZE CRYPTER
Tony Montana Crypter
ToolStore Crypter
ToP GUI Full
Top Secret
Top secret Crypter
Topansko Crypter
TOPO GIGIO CRYPTER
Tornado Crypter
Touch Crypter
Toulouse Crypter
TOXIC CRYPTER
Toy Joy
Toy Story Crypter
TPPpack
Trance Crypter
Transilvania Crypter
Trebol Crypt
Trendy Nigger Binder
TRIBAL CRYP
Tribal Crypter
TRIBAL PROTECTOR
Tricampeones Crypter
TrickySigner
Triforce Crypter
TRIPEX CRYPTER
Triple X Crypter
Trojan Sakla
Trojka Crypter
Tron Legacy Crypter
True MOD
TrueEP
TrurghyBinder
TSH PRIV8 CRYPTER
TsT Binder
TsT Crypter
TTProtect
Tu Aspirina Crypter
TU_AVIRA
Tubby Crypt
tuenti Crypter
Tuning Crypter
Tunning Crypter
Tupac Crypter
Turkish Cyber Signature
Turkojan Binder
Turkojan Crypter
Tuti Fruti Crypt3r
Tux Crypter
Twin Skulls Crypter
twinkle crypt
TYV Crypter
uBind
uBinder
UD TOOLS SIMPLE CRYPTER
UDT Crypter
UdTools Crypter
UdTools Protector
UFO Crypter
UFR Crypter
UG Chruncher
UK Crypter
Ultimate Sharingan Crypter
UltraProtect
Umbrella Cryptor
Un Crypter
Un Simple Crypter
Under S3H Protector
Underc0de Crypter
Underc0de Easy Joiner
Underc0de Priv8
Underc0de Public Crypt0r
Undercode binder
UnderCode CryptOr
UNDERCOVER Crypter
UnderGround Crypter
UnderWorld Crypter
Undetected
Undetector
UnDo Crypter
Union Crypter
UniProtect
Unique RunPe Maker
Universal Crypter
Universo Crypter
Univision Crypter
uNK Binder
uNk Crypter
uNkcrypt0r
Unknow Crypt
UnKnOwN Crypter
UnknownZ Crypter
unkOwn Crypter
UnLimited Crypter
unNamed ProTector
unnamed Scrambler
UnOpix
UnOpixScrambler
UPack
uPack Mutantor
Upc
UPolyX
UProtector
UPX
UPX Crypt
UPX Cryptor
UPX Inkvizitor
UPX Lock
UPX Mutanter
UPX Protector
UPX$hit
UPX-Scrambler
UPXFail
UPXFreak
UPXRedir
UPXScramb
Urach Protector
URANUS Crypter
Uroboros Crypter
US Crypter
Useless Binder
Useless Crypter
USSR
v0id's Crypter 2013
vaCipher
Vai uma FRESQUINHA
Valencia C.F. Crypter
Valencia Crypter
Valentino Rossi Crypter
VALERIA PROTECTOR
Vampir Crypter
VAMPIRE CRYPT
Vampires In Society
Vaquera Crypter
VB-PE-Crypt
VB-PowerWrap
VB2012 Crypter
VB6 BLACK PROTECTOR
VB6 Crypt0r
VB6 DRAGON PROTECTOR
VB6.CRYPTER
VBC Crypt
VBC Joiner
VBEXEObfuscator
vBinder
VBOWatch Protector
Vbs Encrypter
VBS Full Undetected
VCrypt
Vegan Crypter
Vegeta Crypter
Vendetta Crypter
Venezuela Crypter
Venom
Venom Crypter
Venomous Ivy
Venuz Crypter
Veracruz Crypter
Veranito Tool
Veronica-Ricci
VeroProtector
VGShrink
Victoria Crypter
Viking Crypter
Viotto Binder
VIP Protector
Viper Lord
Viprasys crypter
ViroGen Crypt
Virtux Binder
VIRUS TOTAL CRYPTER
Visual Protect
Viviane Araujo Crypter
Vlz
VMProtect
Vooodoo Crypter
VORTEX Crypter
VoyComoUnDisparo Crypter
VPacker
vr46 volador
VT FucKer
Vuvuzela Crypter
VXPack
Wal999
Wallpaper Crypter
Wally Crypter
War Kingz Crypter
Warner2010 Crypt3r
warra_crypter
warrilla_crypter
Warrior Crypter
Warrior_CRYPT
WASSAP crypter
WeeD Crypter
Weed FUD Cripter
Weekend Binder
Werus Crypter
Wes, we cam
Wh1t3bird Protector
White Protector
White widdow
WhiteEye Crypter
Whitell Crypt
WHY SO SERIOUS
Win TroYanizer
Wind of Crypt
Window crypter
Windows 95 Crypter
Windows Crypter
WingsCrypt
WinJar
WinKrypt
WinLicense
WinLite
WinUpack
Wish CRYPT
Wizzard Crypter
WL-Crypt
Wolf Crypter
WOLVERINE Crypt3r
Wolverine Crypter
Wolverinhe Protector
Woman Terrorific
Wombat Crypter
Wonderx Crypter
Worm Crypt
Worms Crypter
WouThrs EXE Crypter
WoW Protector
Wrapper
Wretch-x Crypter
WTF Crypter
WWPack32
X-Core Crypter
X-Crypter
X-ExeJoiner
X-files Crypt
X-N2Binder
X-SHADOW Crypter
X2binder
Xa0s Joiner
Xa0s Simple Joiner
xAVx Crypter
XComp
XcR
xCrypt
xdz-Crypter
xebroom
Xenocrypt
XenoN Crypter
Xfactor
xHacker Crypter
Xinfiltrate Crypter
Xmen 2 Protector
XPack
Xpro Binder
Xpro Crypter
xProtect
Xtreme Crypt
XXPack
XXX CRYPT
Xypt Crypter
Y-W Binder
Yaoming Crypter
Yeah Blinder
Yeikel Crypter
Yet Another Binder
yet another useless crypter
YinCrypt
Yo Mate a Avira Crypter
Yoda's Crypter
Yoda's Protector
Yokoh Crypter
Yorll Crypter
Yorllcito Crypter
Yoshistr Crypter
Youtube Crypter
Yu-Gi-Oh!
YUNO--CRYPT
Yury Boyka
YZPack
YZProtector
Z Crypt
Z04 Crypter
ZaKaraBrUx PD TEAM
Zaleo_Crypt
ZAMBA MC
ZeldaCrypt
ZeroCrypter
ZipWorx SecureEXE
Zombie Crypter
ZOMBIE OCTOPUS CRYPTER
Zombie's joiner
Zombies Crypter
ZOMBIES HOLLYWOOD
zOok Crypt0r
Zorrilla Crypter
ZProtect
Zumito Crypter
ZXCriptor
ZXProtector
Zylom Wrapper
------------------------------
2981 known binders, crypters, packers and protectors and many others...

x64 version successfully tested on:

Armadillo x64
ASProtect x64
Enigma x64
eXPressor x64
MPress x64
NsPack x64
Obsidium x64
PeSpin x64
VMProtect x64

QuickUnpack tries to bypass all possible scramblers/obfuscators and restores redirected import. From the version 1 the opportunity of unpacking dll is added. From the version 2 the attach process feature added which allows to use QuickUnpack as a dumper and import recoverer. Scripts are also supported from version 2 which allows unpacking of more complicated protections. Version 3 brought x64 support and hardware virtualization debugging engine. This makes QuickUnpack a unique software product which has no similar analogues in the world!

Use force unpacking tick. When the application is run QuickUnpack waits for the OEP breakpoint to trigger. But sometimes this breakpoint may be triggered several times but only the last one is the correct OEP. Using ForceMode option solves this problem. With this option after the application is run QuickUnpack counts breapoint hits and dumps the application only at the last stop. For DLL-files this option is always ticked and allows to restore relocs.

If you have any suggestions or found any bugs please tell me about them. You can find me at exelab.ru forum or exetools.com forum or tport.org forum

The license and rights
----------------------
The list of sources used in coding QuickUnpack:
stripper asprotect unpacker by syd
GenOEP.dll by Snaker
Mediana disassembler by Mikae
Marquee creeping line by Funbit/TSRh
plugins and some other code by NEOx
MiniFMOD by Firelight Technologies
the SEException code by Martin Ziacek
Picture (Implementations) by Dr. Yovav Gad
for OEP finders the author is mentioned in the program
Lua scripting language from http://www.lua.org

Versions history
----------------
v4.3 [23.08.2018]
[!] fixed several bugs and made improvements
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts
[+] updated Lua to 5.3.4
[+] added cpuid hooking
[-] removed plugins and import trace plugins
[-] int3 and int6 hooking removed

v4.2 [14.10.2016]
[!] fixed several bugs and made improvements
[+] new import sorting type added
[+] hardcore try to use old IAT method added
[+] updated disassemler
[+] enlarged protectors list

v4.1 [03.11.2014]
[!] fixed several bugs and made improvements
[+] added AMD hardware virtualization based debugging engine
[+] added deletion of long zero sequences from sections
[+] updated generic OEP finder by Dilla
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts
[+] updated Lua to 5.2.3

v4.0 [20.05.2013]
[!] fixed several bugs and made improvements
[+] enlarged protectors list
[+] updated Lua to 5.2.2

v3.8 [02.11.2012]
[!] fixed several bugs and made improvements
[!] rebuilt in unicode
[+] added Intel hardware virtualization based debugging engine
[+] added int0e hooking and memory breakpoints
[+] updated Lua to 5.2.1
[+] enlarged protectors list
[+] added several new functions and variables for the scripts
[-] int4 hooking removed

v3.7 [22.06.2012]
[!] fixed several bugs and made improvements
[!] resource rebuilder rewritten, all tree levels are rebuilt dynamically
[!] export rebuilder rewritten
[+] updated Lua to 5.2
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.6 [25.10.2011]
[!] fixed several bugs and made improvements
[+] added GetLoadDll.dll to find necessary breakpoint address
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.5 [14.03.2011]
[!] fixed several bugs and made improvements
[+] added unicode support
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.4 [15.08.2010]
[!] fixed several bugs and made improvements
[!] QU now tries to use old IAT at first
[!] completely rewrote Force OEP finder
[+] all direct import references are processed now, not just call xxx/jmp xxx
[+] Time delta can be automatically calculated
[+] many header fields are now recomputed, almost all the header is rebuilt
[+] updated generic OEP finder by Dilla
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts
[-] ImpRec compatibility is now broken
[-] removed protection identifiers

v3.3 [05.05.2010]
[!] moved to Visual Studio 2008 SP1
[!] fixed several bugs and made improvements
[!] driver name, service name and symbolic link are now randomly generated
[!] refactored the engine and made it 1.5 times faster
[+] path building for import libraries added
[+] export table rebuild ability added while cutting sections
[+] log autosave ability added, logs are written into Logs folder if strings>5000
[+] updated generic OEP finder by Dilla
[+] updated disassemler
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.2 [22.11.2009]
[!] fixed several bugs and made improvements
[!] rewrote driver a bit to avoid synchronization bugs
[!] completely rewrote deroko's OEP finder to make it faster and more stable and make it work under x64. sometimes doesn't work under virtual machines
[!] completely rewrote Human's OEP finder to make it work under x64
[!] completely rewrote UsAr's OEP finder with LaZzy to make it work under x64
[!] took a completely new disassembler now also available under x64
[!] x64 version is completely finished with all the functionality
[+] added new generic OEP finder by Dilla
[+] forwarded import functions are now processed automatically
[+] enlarged protectors list
[+] added several new functions and variables for the scripts

v3.1 [17.04.2009]
[!] fixed several bugs and made improvements
[+] enlarged protectors list
[+] sound engine changed to MiniFMOD 1.70. after a day of fucking it also began to work on x64
[+] added several new functions and variables for the scripts

v3.0 [30.11.2008]
[!] fixed several bugs and made improvements
[+] 14.09.2008 x64 version was born
[+] 06.11.2008 the first x64 file was unpacked
[+] enlarged protectors list
[+] updated ufmod to 1.25.2a
[+] added several new functions and variables for the scripts

v2.3 [14.09.2008]
[!] decided to make this private. If you're reading this, I guess you're one of the guys whom I trust, don't fail me
[!] fixed several bugs and made improvements
[!] the program is divided into sections correctly, access attributes and names are added
[+] updated Lua to 5.1.4
[+] added ability to manually choose RVA to cut sections at
[+] significantly enlarged protectors list
[+] added several new scripts
[+] added several new functions and variables for the scripts

v2.2 [25.06.2008]
[!] fixed several bugs and made improvements like quickened import processing
[+] RDTSC delta also affects GetTickCount now
[+] updated Lua to 5.1.3
[+] updated UsAr's generic OEP finder
[+] modified Human's generic OEP finder to find OEP in DLLs
[+] modified deroko's generic OEP finder to find OEP in DLLs
[+] added Save log feature to the main menu
[+] added support of different languages, just create your own lng-file and enable it at the preferences window
[+] added delphi initialization table restoration. Be sure to turn this on only for Delphi programs
[+] finished the work on the memory manager which allows to collect all the allocated memory into one image (private version only)
[+] added several new functions and variables for the scripts
[+] changed a bit RDTSC hook. if the most significant bit is set in delta QuickUnpack calculates the delta itself

v2.1 [31.03.2008]
[!] fixed many bugs like crash on some applications while restoration of resources
[!] multithreaded applications are now handled properly
[+] added ability to set end of module when tracing import functions. When a reference to import is found it's analyzed if it leads to some space outside of the module (not to trace some internal functions). But some packers redirect import to the last section. This option is intended to aid this problem. This is RVA
[+] added ability to put import table at given RVA instead of adding extra section
[+] added ability to set RDTSC delta for RDTSC hook (see more on rdtsc_delta in Scripts.eng.txt)
[+] Load libraries only option added to import recovery methods. this option doesn't actually recover import it just puts 1 import function from every loaded DLL into the import table. thus dump will be loaded with all the necessary libraries and will use old addresses for import functions which were set by a protector. this option can be used if import redirection is too complicated but the dump will stop working after service pack or some other patch installation
[+] Execute functions while tracing import option is added. by default while tracing import functions are not executed but some protectors need result of these functions to operate correctly so this option can be used
[+] Process call xxx/jmp xxx option is added. some protectors change import calls and jumps from call [xxx]/jmp [xxx] to call xxx/jmp xxx. this option is intended to work also with these redirections
[+] added several new functions and variables for the scripts
[+] UsAr's generic OEP finder now supports DLLs
[+] new Vista manifest added

v2.0 final [13.09.2007]
[!] fixed many bugs like missed import functions
[!] fixed several driver bugs like the one which didn't allow to pass some exceptions
[!] improved export feature now supports invalid functions
[!] many improvements (like 256x256 icon for Vista, thanks to Feuerrader :)) and optimizations (like better memory handling)
[!] now Force.dll doesn't use GenOEP.dll, though some code was borrowed
[+] added so long-waited ability to use scripts. before using scripts it's strongly recommended to read the manual (Scripts.eng.txt file). script examples may be taken from Scripts folder (*.txt files), scripting language Lua manual also can be found there (Lua Manual.html), which parser was embedded in the program. BTW I know that Step button doesn't work like a charm but I wasn't able to make it better
[+] passing parameters to the application added
[+] import list from ImpRec feature added (now QuickUnpack supports both export and import of import functions in ImpRec-compatible files this allows to edit some functions or add new ones. keep in mind this option works with normally created files but if you put some garbage or format this file in unusual manner this may cause crash :) I was too lazy to parse the file with care)
[+] attach process feature added (this option allows to choose any module in a process for unpacking and has some features. if in processes listbox a process name is a full path with name you can attach to this process. if it is only name of the file you don't have enough rights to attach. you can't specify the OEP, the instruction the program was stopped is treated as the OEP. to use attach process feature one should load the program in any debugger and manually get to the OEP, when attach to that process with QuickUnpack. keep in mind that for smart import recovery you don't need the program to run, it can just be left in the debugger standing at the breakpoint. but to use smart import recovery with tracer you should put it in the infinite loop (EB FE) and run the program because the tracer uses current thread for tracing. if the program was put in the infinite loop don't forget to restore these two bytes in the dump. when attached tracing import is unreliable and very slow, so it's not recommended to use it). this feature allows to use QuickUnpack as a dumper and import recoverer (my attempt to replace PETools and ImpRec with one program :))
[+] ImpRec plugin support added (this feature allows to use ImpRec tracer plugins in QuickUnpack to restore import functions. keep in mind when using attach to process feature the program must be run for the tracer to work)
[+] added UsAr's generic OEP finder. I modified it a bit
[+] added Human's generic OEP finder. I modified it a bit
[+] added deroko's generic OEP finder. I modified if a bit and took the GUI from Human's generic OEP finder. it's sometimes slow but rather powerful and be warned that this finder uses driver and the driver is unloadable till next reboot. uses deroko's Dream of every reverser engine so incompatible with win2k3 and kaspersky. for more information about this engine visit http://deroko.phearless.org
[-] no more old non-generic OEP finders

v1.0 final [18.06.2007]
Unfortunately Feuerrader has left this project, so from now on I'm (Archer) is the only developer.

[!] several bugs fixed like possible tls corruption when removing sections or possible program crash when reading false relocations
[!] identifies dll according to the flag in the header instead of the extension
[!] improved import tracer doesn't fail to trace emulated functions
[+] overlay append option added
[+] ability to disassemble import functions (if some function was emulated you may use this to identify the function)
[+] ability to add new library (allows to use import functions from the new library when editing import functions. also while loading the library the program stands at the OEP, so you can use your own library to do something with the import or with the program)
[+] ability to edit import functions (allows to fix some import functions by hand. the edit window supports typing function's name on the keyboard along with the choosing it in the listbox)
[+] option to add suspicious functions (allows to add possibly emulated functions to the import table to fix them by hand later using new feature above. be warned that false functions may be also added and they must be removed)
[-] no more ImpRec.dll (this method was rather buggy, others methods are more powerful, so I decided to remove this one)

v1.0 RC1 [12.03.2007]
[!] Sections are truncated properly
[+] New feature - resource rebuilder and tracer (restores redirected import)! Now it handles simple protectors, ex. Yoda Protector
[!] Critical errors are now reported
[!] Get unloaded properly after crash
[!] Some bugfix and optimized code
[!] Fixed ImpRec method
[!] Fixed Force Mode
[!] The driver has been rewritten with improved rdtsc emulation and changed breakpoints   

[05.02.2007]
v1.0 beta8 [!] Bug fixed with Always on top option
	   [!] Bug fixed with BSOD and unterminated processes
	   [!] Optimized import recovery by syd's method
	   [+] Added export import tree to ImpRec
	   [+] Updated engine.sys
	   [!] Bug fixed with dll unpacking
	   [!] Bug fixed with old upx versions on dll
	   [!] Kill target button works correctly now
	   [!] View of import table was changed
	   [+] Find object button added

[21.01.2007]
v1.0 beta7 [+] Improved interface
	   [+] Fixed small bugs

[22.10.2006]
v1.0 beta6 [!] Internal build

[13.05.2006]
v1.0 beta5 [+] Support of unpacking UPX 2.0
           [+] New signature list
           [+] New engine from stripper 2.13 b9

[26.01.2006]
v1.0 beta4 internal [!] bugfixes

[26.08.2005]
v1.0 beta3 [+] an opportunity of unpacking dlls is added
           [+] an opportunity of using plug-ins and own OEP finders is added

[20.03.2005]
v0.7 [!] Based on updated stripper 2.11 rc3 engine => new features
     [+] Force mode added v0.6 [!] Final build

[13.02.2005]
v0.6 [!] Final build

[10.01.2005]
v0.5 [+] QuickUnpack now uses new engine and works through external tracer engine.sys. No debug API is used
     [+] Dump and PE header are very clean after unpacking
     [+] Cool OEP finder for packers

[25.07.2004]
v0.43. [+] The opportunities of ImpRec.dll were added. It will be useful, I think
       [+] Protection from IsDebuggerPresent was added (a tick "Hide unpacker")
       [!] This version is last, I think, as the opportunities of Debug API are fully used

[10.07.2004]
v0.41. [!] Fixed the bug with the unpacked programs compatibility on the different OS (the bug with RestoreLastError)

[12.03.2004]
v0.4 final. Final build. All the mistakes were fixed

[29.02.2004]
v0.3. [+] The engine working with the dump is completely re-coded
	  Now the engine from PE Tools by NEOx [uinC] is used
      [+] The system of "clever" dump rebuilding and optimizing its size is supported
	  The engine of the dump rebuilding from PE Tools by NEOx [uinC] was used
      [!] Picture of QuickUnpack was removed :) 
      [+] Packers with damaged headers (e.g. FSG) are supported
      [+] The bugs in the operations with PE files were fixed

[21.02.2004]
v0.2. The first version. All as is

Greetz and thanks
-----------------
tPORt, AHTeam, TSRh, KpTeam, REVENGE, CRACKL@B, ICU members, CoaxCable^CPH, Wild-Wolf and all CPH members on #cph, LaFarge[ICU] and SofT MANiAC for nice music, SergioPoverony, DillerInc, newborn for logo, syd, lord_Phoenix, NCRangeR, Grim Fandango, Aster!x, Quantum, MozgC, Sten, PolishOX, NEOx, WELL, GPcH, Funbit, sl0n, Ms-Rem, Bad_guy, dj-siba, =TS=, DillerInc, UsAr, Human, deroko, Errins, Bronco, HandMill, Executioner, 4kusN!ck, BiT-H@ck, Hellsp@wn, HoBleen, Smon, LaZzy, Mikae...