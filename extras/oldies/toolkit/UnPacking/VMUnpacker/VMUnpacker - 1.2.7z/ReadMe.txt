VMUnpacker V1.2

    This tool based on the technology of virtual machine, it could unpack various known & unknown shells. It is suitable for unpacking the shelled Trojan horse in virus analyses, and because all codes are run under the virtual machine, so they will not take any danger to your system..

    This product is free software; you can download it, install it, copy it and distribute it noncommercially; If you want use it for commercial sale, copy and distribute, you must get the warranty and permission of DSWLAB before(for example, if the anti-virus company want to use it to analyses the Trojan horse in batches, he must get mandate and permission of DSWLAB before). 

    By testing, this version could support 57 kinds shells (include 300 versions).
����The detailed list:
����
    upx 0.5x-3.00  All Version
    BeRoEXEPacker
    aspack 1.x--2.x   All Version
    PEcompact 0.90--1.76 2.06--2.79   All Version
    fsg v1.0 v1.1 v1.2 v1.3 v1.31 v1.33 v2.0  All Version
    vgcrypt v0.75
    nspack 1.4--4.1  All Version
    expressor v1.0 v1.1 v1.2 v1.3 v1.4 v1.501  
    npack v1.5 v2.5 v3.0 
    dxpack v0.86 v1.0
    !epack v1.0 !epack v1.4
    bjfnt v1.2 v1.3
    mew5 mew v1.0 v1.1
    packman v1.0
    PEDiminisher v0.1
    pex v0.99
    petite v1.2 v1.3 v1.4 v2.2 v2.3  All Version
    winkript v1.0
    pklite32
    pepack v0.99 v1.0
    pcshrinker v0.71
    wwpack32 1.0--1.2
    upack 0.1--0.32 0.33--0.399
    rlpack 1.11--1.14 1.15--1.18
    exe32pack v1.42
    kbys v0.22 v0.28  
    yoda's protector v1.02 v1.025 v1.03.2
    yoda's crypt v1.1
    yoda's crypt v1.2 v1.3 v1.xModify
    XJ  
    exestealth  2.72--2.76
    hidepe v1.0 v1.1
    jdpack v1.01 v2.1 v2.13
    jdprotect 0.9b
    PEncrypt v3.0 v3.1 v4.0
    Stone's PE Crypt v1.13
    telock v0.42 v0.51 v0.60 v0.70 v0.71 v0.80 v0.85 v0.90 v0.92 v0.95 v0.96 v0.98 v0.99 
    ezip
    hmimys_pack v1.0
    lamecrypt v1.0
    depack
    polyene v0.01
    dragonArmour
    EP Protector v0.3
    PackItBitch
    trojan_protect  
    anti007 v2.5 v2.6
    mkfpack
    yzpack v1.1  v2.0
    spack method1  spack method2
    naked packer v1.0
      
    upolyx v0.51 
    stealthPE v1.01   stealthPE v2.2  
    mslrh v0.31 v0.32
    mslrh v0.2 == [G!X]'s Protect
    morphine v1.3 morphine v1.6 morphine v2.7
    rlpack full edition


VM Unpack Engine SDK��

The commercial VM Unpack Engine SDK will be provided solemnly (VM Unpack Engine SDK).

Use VM Unpack Engine SDK, the developer does not need to care about the unpacked course and method, only needs to transmit the data to VMUE SDK, VMUE will finish analyzing and unpacking automatically. VMUE supports to send the result of unpacking to the file and memory at the same time,  and returns OEP after unpacking directly, It help you unpack shells in your products and tools. 
    
Rebuild PE file after unpacking, such as repair the import table, Overlay, etc. offer the essential condition that rebuilding can running EXE program. 

VMUE SDK includes the following part mainly: 

	Relevant dynamic or static libraries 
	VMUE SDK technological white paper and the document about the interface of SDK
	Codes of calling VMUE SDK
	Shell's signature library in binary 
	Other auxiliary routines and codes

Welcome to use this software and feedback the question to support@dswlab.com 
    
If you have any question in using, send us email and we will try to help; please post the unpacked program in mail; it is better that you post the packed tool of the program.
Email: support@dswlab.com.


