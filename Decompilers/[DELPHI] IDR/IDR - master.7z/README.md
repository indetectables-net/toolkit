# IDR
Interactive Delphi Reconstructor
IDR (Interactive Delphi Reconstructor) – a decompiler of executable files (EXE) and dynamic libraries (DLL), written in Delphi 
and executed in Windows32 environment.

The program firstly is intended for the companies, engaged by development of anti-virus software. It can also help programmers 
to recover lost source code of programs appreciably.

The current version of the program can process files (GUI and console applications), compiled by Delphi compilers of versions 
Delphi2 – Delphi XE4.

Final project goal is development of the program capable to restore the most part of initial Delphi source codes from the 
compiled file but IDR, as well as others Delphi decompilers, cannot do it yet. Nevertheless, IDR is in a status considerably 
to facilitate such process. In comparison with other well known Delphi decompilers the result of IDR analysis has the greatest 
completeness and reliability. Moreover interactivity does work with the program comfortable and (we shall not be afraid of 
this word) pleasant.

IDR make static analysis (analyzed file is not loaded to memory and executed) that allows to safely investigate viruses, 
trojans and other malware applications, those which executing is dangerous or is not desirable.

The program does not require any installation activity and does not do any records in Windows registry.

Use Borland C++ Builder 6 to build this project.

IDR dont require any installations, just copy idr.exe, dis.dll, icons.dll, idr.ico and *.bin files
to IDR home directory. Message "Cannot Initialize Disasm" means that file dis.dll is absent.

!!!
Knowledge bases for various Delphi versions can be found at:
https://www.dropbox.com/sh/9ran313nidqtagb/AADl_m_9GVYSiXUviZtDQWQHa?dl=0
