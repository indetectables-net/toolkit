This requires Visual Studio 2015 Redistributable to run, download it and install it here:
https://www.microsoft.com/en-ca/download/details.aspx?id=48145