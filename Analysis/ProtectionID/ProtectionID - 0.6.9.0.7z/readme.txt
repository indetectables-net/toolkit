Here's the december public beta of ProtectionID version 0.6.9.0.. Apologies for missing the halloween release, I really didnt have time.

This version has quite a few tweaks to existing scans, the scan count hasnt gone up but has been made more accurate in detections. Some bugs were fixed, and ProtectionID should run on win 95 -> win 10 (and higher) as it always did.

I plan to do a release in the new year, fixing any bugs reported, as well as adding in a settings change choice that i forgot about.

I hope you enjoy the new changes and addition, please read the license.txt file, for most
of you this doesnt really matter, but for some it does, as the license model changed,
thanks (as usual) to the beta testers, your help and feedback was incredibly useful.

Also theres an optional donate button, should you feel like wanting to donate towards the
further development of ProtectionID (v7 is in the works, so this version and possibly the
christmas / holiday season release may be the last version 6 public release.

Coming in the next release (possibly january) - bug fixes and tweaks.

Suggestions, bug reports, new files to have their signatures added, false positives etc
are all welcome, just email at the usual email address protectionidteam@outlook.com

I have added the virus total report for the file, i have also (as usual) included the current
virustotal output results for this release, any detections i assure you they are false positives and i will be working on getting any detections whitelisted, but please make sure you download the ProtectionID release from the home site -> pid.gamecopyworld.com
url..

Also, if anyone wants to write a manual for ProtectionID or redesign the web page (my
html skills are non existant) please feel free to contact me too

oh, and happy holidays :)

/TippeX